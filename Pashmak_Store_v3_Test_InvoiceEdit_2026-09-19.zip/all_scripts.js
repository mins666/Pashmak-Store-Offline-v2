
const seed={"products": [{"code": "K0001", "name": "عسل چهل گیاه یک کیلویی", "unit": "عدد", "min": 0, "defaultWarn": null}, {"code": "K0002", "name": "عسل چهل گیاه نیم کیلویی", "unit": "عدد", "min": 0, "defaultWarn": null}, {"code": "K0003", "name": "عسل کنار یک کیلویی", "unit": "عدد", "min": 0, "defaultWarn": null}, {"code": "K0004", "name": "عسل کنار نیم کیلویی", "unit": "عدد", "min": 0, "defaultWarn": null}, {"code": "K0005", "name": "عسل گون یک کیلویی", "unit": "عدد", "min": 0, "defaultWarn": null}, {"code": "K0006", "name": "عسل گون نیم کیلویی", "unit": "عدد", "min": 0, "defaultWarn": null}, {"code": "K0007", "name": "عسل آویشن یک کیلویی", "unit": "عدد", "min": 0, "defaultWarn": null}, {"code": "K0008", "name": "عسل آویشن نیم کیلویی", "unit": "عدد", "min": 0, "defaultWarn": null}, {"code": "K0009", "name": "عسل دارویی یک کیلویی", "unit": "عدد", "min": 0, "defaultWarn": null}, {"code": "K0010", "name": "عسل کوهی یک کیلویی", "unit": "عدد", "min": 0, "defaultWarn": null}, {"code": "K0011", "name": "عسل کوهی نیم کیلویی", "unit": "عدد", "min": 0, "defaultWarn": null}, {"code": "K0012", "name": "عسل وحشی کوهستان یک کیلویی", "unit": "عدد", "min": 0, "defaultWarn": null}, {"code": "K0013", "name": "عسل وحشی کوهستان نیم کیلویی", "unit": "عدد", "min": 0, "defaultWarn": null}, {"code": "K0014", "name": "سه شیره کوچک", "unit": "عدد", "min": 0, "defaultWarn": null}, {"code": "K0015", "name": "شیره انگور کوچک", "unit": "عدد", "min": 0, "defaultWarn": null}, {"code": "K0016", "name": "شیره انگور بزرگ", "unit": "عدد", "min": 0, "defaultWarn": null}, {"code": "K0017", "name": "شیره خرما", "unit": "عدد", "min": 0, "defaultWarn": null}, {"code": "K0018", "name": "ارده شابلی کوچک", "unit": "عدد", "min": 0, "defaultWarn": null}, {"code": "K0019", "name": "ارده شابلی بزرگ", "unit": "عدد", "min": 0, "defaultWarn": null}, {"code": "K0020", "name": "ارده شیررضا ساده", "unit": "عدد", "min": 0, "defaultWarn": null}, {"code": "K0021", "name": "ارده شیررضا دو آتیشه", "unit": "عدد", "min": 0, "defaultWarn": null}, {"code": "K0022", "name": "شیره کشمش", "unit": "عدد", "min": 0, "defaultWarn": null}, {"code": "K0023", "name": "کره بادام‌زمینی پرارین (زرد)", "unit": "عدد", "min": 0, "defaultWarn": null}, {"code": "K0024", "name": "کره بادام‌زمینی پرارین (آبی)", "unit": "عدد", "min": 0, "defaultWarn": null}, {"code": "K0025", "name": "کره بادام‌زمینی پرارین (سبز)", "unit": "عدد", "min": 0, "defaultWarn": null}, {"code": "K0026", "name": "حلوا ارده شیره انگور شیررضا", "unit": "عدد", "min": 0, "defaultWarn": null}, {"code": "K0027", "name": "حلوا ارده شیره خرما شیررضا", "unit": "عدد", "min": 0, "defaultWarn": null}, {"code": "K0028", "name": "حلوا شکری شیررضا", "unit": "عدد", "min": 0, "defaultWarn": null}, {"code": "K0029", "name": "فرمند پلاستیکی", "unit": "عدد", "min": 0, "defaultWarn": null}, {"code": "K0030", "name": "فرمند دو رنگ ۲۰۰ گرمی", "unit": "عدد", "min": 0, "defaultWarn": null}, {"code": "K0031", "name": "فرمند ۱۰۰ گرمی دورنگ", "unit": "عدد", "min": 0, "defaultWarn": null}, {"code": "K0032", "name": "فرمند ۱۰۰ گرمی فندوقی", "unit": "عدد", "min": 0, "defaultWarn": null}, {"code": "K0033", "name": "فرمند ۱۰۰ گرمی تلخ", "unit": "عدد", "min": 0, "defaultWarn": null}, {"code": "K0034", "name": "فرمند ۳۳۰ گرمی فندوقی", "unit": "عدد", "min": 0, "defaultWarn": null}, {"code": "K0035", "name": "مرداس دو رنگ ۱۸۰ گرمی", "unit": "عدد", "min": 0, "defaultWarn": null}, {"code": "K0036", "name": "حلوا ارده ۵۰۰ گرمی شابلی", "unit": "عدد", "min": 0, "defaultWarn": null}, {"code": "K0037", "name": "حلوا ارده شیررضا ۵۰۰ گرمی", "unit": "عدد", "min": 0, "defaultWarn": null}, {"code": "K0038", "name": "مربا آلبالو شانا", "unit": "عدد", "min": 0, "defaultWarn": null}, {"code": "K0039", "name": "مربا به شانا", "unit": "عدد", "min": 0, "defaultWarn": null}, {"code": "K0040", "name": "مربا گیلاس شانا", "unit": "عدد", "min": 0, "defaultWarn": null}, {"code": "K0041", "name": "مربا بالنگ شانا", "unit": "عدد", "min": 0, "defaultWarn": null}, {"code": "K0042", "name": "مربا تمشک شانا", "unit": "عدد", "min": 0, "defaultWarn": null}, {"code": "K0043", "name": "مربا هویج شانا", "unit": "عدد", "min": 0, "defaultWarn": null}, {"code": "K0044", "name": "مربا پرتغال شانا", "unit": "عدد", "min": 0, "defaultWarn": null}, {"code": "K0045", "name": "مربا آلبالو کوچک شانا", "unit": "عدد", "min": 0, "defaultWarn": null}, {"code": "K0046", "name": "مربا هویج کوچک شانا", "unit": "عدد", "min": 0, "defaultWarn": null}, {"code": "K0047", "name": "مربا آلبالو موسوی", "unit": "عدد", "min": 0, "defaultWarn": null}, {"code": "K0048", "name": "مربا هویج موسوی", "unit": "عدد", "min": 0, "defaultWarn": null}, {"code": "K0049", "name": "مربا هویج زعفران موسوی", "unit": "عدد", "min": 0, "defaultWarn": null}, {"code": "K0050", "name": "مربا بالنگ موسوی", "unit": "عدد", "min": 0, "defaultWarn": null}, {"code": "K0051", "name": "مربا تمشک موسوی", "unit": "عدد", "min": 0, "defaultWarn": null}, {"code": "K0052", "name": "مربا به موسوی", "unit": "عدد", "min": 0, "defaultWarn": null}, {"code": "K0053", "name": "مربا انجیر موسوی", "unit": "عدد", "min": 0, "defaultWarn": null}, {"code": "K0054", "name": "عرق بیدمشک 1&1", "unit": "عدد", "min": 0, "defaultWarn": null}, {"code": "K0055", "name": "عرق نعنا 1&1", "unit": "عدد", "min": 0, "defaultWarn": null}, {"code": "K0056", "name": "گلاب ربیع", "unit": "عدد", "min": 0, "defaultWarn": null}, {"code": "K0057", "name": "سیر مروارید اصالت", "unit": "عدد", "min": 0, "defaultWarn": null}, {"code": "K0058", "name": "سیر گل اصالت", "unit": "عدد", "min": 0, "defaultWarn": null}, {"code": "K0059", "name": "ترشی لیته اصالت", "unit": "عدد", "min": 0, "defaultWarn": null}, {"code": "K0060", "name": "ترشی لیته بندری اصالت", "unit": "عدد", "min": 0, "defaultWarn": null}, {"code": "K0061", "name": "ترشی فلفل سوزنی اصالت", "unit": "عدد", "min": 0, "defaultWarn": null}, {"code": "K0062", "name": "زیتون ایتالیایی اصالت", "unit": "عدد", "min": 0, "defaultWarn": null}, {"code": "K0063", "name": "کنسرو لوبیا با قارچ اصالت", "unit": "عدد", "min": 0, "defaultWarn": null}, {"code": "K0064", "name": "سس گوجه فرنگی اصالت", "unit": "عدد", "min": 0, "defaultWarn": null}, {"code": "K0065", "name": "سس گوجه‌فرنگی تند اصالت", "unit": "عدد", "min": 0, "defaultWarn": null}, {"code": "K0066", "name": "آبلیمو ناصر - خرید اول", "unit": "عدد", "min": 0, "defaultWarn": null}, {"code": "K0067", "name": "آبلیمو ناصر - خرید دوم", "unit": "عدد", "min": 0, "defaultWarn": null}, {"code": "K0068", "name": "رشته آشی اصفهان گل گندم", "unit": "عدد", "min": 0, "defaultWarn": null}, {"code": "K0069", "name": "رشته پلویی عقیلی", "unit": "عدد", "min": 0, "defaultWarn": null}, {"code": "K0070", "name": "رشته آشی عقیلی", "unit": "عدد", "min": 0, "defaultWarn": null}, {"code": "K0071", "name": "تروبیکا", "unit": "عدد", "min": 0, "defaultWarn": null}, {"code": "K0072", "name": "گود دی", "unit": "عدد", "min": 0, "defaultWarn": null}], "layers": [{"id": "L0001", "code": "K0001", "qty": 9, "remaining": 9, "cost": null, "price": 950000, "buyDate": "2026-09-05", "exp": null, "warn": null}, {"id": "L0002", "code": "K0002", "qty": 20, "remaining": 20, "cost": null, "price": 490000, "buyDate": "2026-09-05", "exp": null, "warn": null}, {"id": "L0003", "code": "K0003", "qty": 8, "remaining": 8, "cost": null, "price": 950000, "buyDate": "2026-09-05", "exp": null, "warn": null}, {"id": "L0004", "code": "K0004", "qty": 1, "remaining": 1, "cost": null, "price": 490000, "buyDate": "2026-09-05", "exp": null, "warn": null}, {"id": "L0005", "code": "K0005", "qty": 2, "remaining": 2, "cost": null, "price": 950000, "buyDate": "2026-09-05", "exp": null, "warn": null}, {"id": "L0006", "code": "K0006", "qty": 17, "remaining": 17, "cost": null, "price": 490000, "buyDate": "2026-09-05", "exp": null, "warn": null}, {"id": "L0007", "code": "K0007", "qty": 7, "remaining": 7, "cost": null, "price": 950000, "buyDate": "2026-09-05", "exp": null, "warn": null}, {"id": "L0008", "code": "K0008", "qty": 6, "remaining": 6, "cost": null, "price": 490000, "buyDate": "2026-09-05", "exp": null, "warn": null}, {"id": "L0009", "code": "K0009", "qty": 7, "remaining": 7, "cost": null, "price": 1200000, "buyDate": "2026-09-05", "exp": null, "warn": null}, {"id": "L0010", "code": "K0010", "qty": 6, "remaining": 6, "cost": null, "price": 1150000, "buyDate": "2026-09-05", "exp": null, "warn": null}, {"id": "L0011", "code": "K0011", "qty": 2, "remaining": 2, "cost": null, "price": 600000, "buyDate": "2026-09-05", "exp": null, "warn": null}, {"id": "L0012", "code": "K0012", "qty": 9, "remaining": 9, "cost": null, "price": 1250000, "buyDate": "2026-09-05", "exp": null, "warn": null}, {"id": "L0013", "code": "K0013", "qty": 10, "remaining": 10, "cost": null, "price": 650000, "buyDate": "2026-09-05", "exp": null, "warn": null}, {"id": "L0014", "code": "K0014", "qty": 4, "remaining": 4, "cost": null, "price": 153000, "buyDate": "2026-09-05", "exp": null, "warn": null}, {"id": "L0015", "code": "K0015", "qty": 4, "remaining": 4, "cost": null, "price": 245000, "buyDate": "2026-09-05", "exp": null, "warn": null}, {"id": "L0016", "code": "K0016", "qty": 4, "remaining": 4, "cost": null, "price": 450000, "buyDate": "2026-09-05", "exp": null, "warn": null}, {"id": "L0017", "code": "K0017", "qty": 2, "remaining": 2, "cost": null, "price": 95000, "buyDate": "2026-09-05", "exp": null, "warn": null}, {"id": "L0018", "code": "K0018", "qty": 25, "remaining": 25, "cost": null, "price": 388000, "buyDate": "2026-09-05", "exp": null, "warn": null}, {"id": "L0019", "code": "K0019", "qty": 15, "remaining": 15, "cost": null, "price": 669000, "buyDate": "2026-09-05", "exp": null, "warn": null}, {"id": "L0020", "code": "K0020", "qty": 10, "remaining": 10, "cost": null, "price": 644000, "buyDate": "2026-09-05", "exp": null, "warn": null}, {"id": "L0021", "code": "K0021", "qty": 4, "remaining": 4, "cost": null, "price": 651000, "buyDate": "2026-09-05", "exp": null, "warn": null}, {"id": "L0022", "code": "K0022", "qty": 3, "remaining": 3, "cost": null, "price": 250000, "buyDate": "2026-09-05", "exp": null, "warn": null}, {"id": "L0023", "code": "K0023", "qty": 6, "remaining": 6, "cost": null, "price": 307000, "buyDate": "2026-09-05", "exp": null, "warn": null}, {"id": "L0024", "code": "K0024", "qty": 8, "remaining": 8, "cost": null, "price": 314000, "buyDate": "2026-09-05", "exp": null, "warn": null}, {"id": "L0025", "code": "K0025", "qty": 2, "remaining": 2, "cost": null, "price": 418000, "buyDate": "2026-09-05", "exp": null, "warn": null}, {"id": "L0026", "code": "K0026", "qty": 2, "remaining": 2, "cost": null, "price": 423000, "buyDate": "2026-09-05", "exp": null, "warn": null}, {"id": "L0027", "code": "K0027", "qty": 1, "remaining": 1, "cost": null, "price": 252000, "buyDate": "2026-09-05", "exp": null, "warn": null}, {"id": "L0028", "code": "K0028", "qty": 1, "remaining": 1, "cost": null, "price": 368000, "buyDate": "2026-09-05", "exp": null, "warn": null}, {"id": "L0029", "code": "K0029", "qty": 1, "remaining": 1, "cost": null, "price": 490000, "buyDate": "2026-09-05", "exp": null, "warn": null}, {"id": "L0030", "code": "K0030", "qty": 3, "remaining": 3, "cost": null, "price": 260000, "buyDate": "2026-09-05", "exp": null, "warn": null}, {"id": "L0031", "code": "K0031", "qty": 2, "remaining": 2, "cost": null, "price": 165000, "buyDate": "2026-09-05", "exp": "۱۴۰۶/۰۴/۲۴", "warn": null}, {"id": "L0032", "code": "K0032", "qty": 4, "remaining": 4, "cost": null, "price": 135000, "buyDate": "2026-09-05", "exp": "۱۴۰۵/۱۱/۲۸", "warn": null}, {"id": "L0033", "code": "K0033", "qty": 1, "remaining": 1, "cost": null, "price": 220000, "buyDate": "2026-09-05", "exp": null, "warn": null}, {"id": "L0034", "code": "K0034", "qty": 2, "remaining": 2, "cost": null, "price": 480000, "buyDate": "2026-09-05", "exp": "۱۴۰۶/۰۳/۲۴", "warn": null}, {"id": "L0035", "code": "K0035", "qty": 2, "remaining": 2, "cost": null, "price": 165000, "buyDate": "2026-09-05", "exp": "۱۴۰۵/۱۰/۱۶", "warn": null}, {"id": "L0036", "code": "K0036", "qty": 3, "remaining": 3, "cost": null, "price": 380000, "buyDate": "2026-09-05", "exp": "۱۴۰۵/۱۰/۰۱", "warn": null}, {"id": "L0037", "code": "K0037", "qty": 2, "remaining": 2, "cost": null, "price": 437000, "buyDate": "2026-09-05", "exp": "۱۴۰۵/۱۰/۲۱", "warn": null}, {"id": "L0038", "code": "K0038", "qty": 6, "remaining": 6, "cost": null, "price": 278000, "buyDate": "2026-09-05", "exp": "۱۴۰۷/۰۳/۱۰", "warn": null}, {"id": "L0039", "code": "K0039", "qty": 6, "remaining": 6, "cost": null, "price": 180000, "buyDate": "2026-09-05", "exp": "۱۴۰۷/۰۳/۰۷", "warn": null}, {"id": "L0040", "code": "K0040", "qty": 4, "remaining": 4, "cost": null, "price": 245000, "buyDate": "2026-09-05", "exp": "۱۴۰۶/۰۹/۱۶", "warn": null}, {"id": "L0041", "code": "K0041", "qty": 7, "remaining": 7, "cost": null, "price": 182000, "buyDate": "2026-09-05", "exp": "۱۴۰۷/۰۳/۱۳", "warn": null}, {"id": "L0042", "code": "K0042", "qty": 3, "remaining": 3, "cost": null, "price": 230000, "buyDate": "2026-09-05", "exp": "۱۴۰۷/۰۲/۰۳", "warn": null}, {"id": "L0043", "code": "K0043", "qty": 12, "remaining": 12, "cost": null, "price": 140000, "buyDate": "2026-09-05", "exp": "۱۴۰۷/۰۵/۲۷", "warn": null}, {"id": "L0044", "code": "K0044", "qty": 6, "remaining": 6, "cost": null, "price": 190000, "buyDate": "2026-09-05", "exp": "۱۴۰۷/۰۲/۲۳", "warn": null}, {"id": "L0045", "code": "K0045", "qty": 2, "remaining": 2, "cost": null, "price": 145000, "buyDate": "2026-09-05", "exp": "۱۴۰۷/۰۲/۰۸", "warn": null}, {"id": "L0046", "code": "K0046", "qty": 5, "remaining": 5, "cost": null, "price": 85000, "buyDate": "2026-09-05", "exp": "۱۴۰۷/۰۲/۰۸", "warn": null}, {"id": "L0047", "code": "K0047", "qty": 12, "remaining": 12, "cost": null, "price": 148000, "buyDate": "2026-09-05", "exp": "۱۴۰۶/۱۰/۲۱", "warn": null}, {"id": "L0048", "code": "K0048", "qty": 11, "remaining": 11, "cost": null, "price": 95000, "buyDate": "2026-09-05", "exp": "۱۴۰۶/۱۰/۰۶", "warn": null}, {"id": "L0049", "code": "K0049", "qty": 10, "remaining": 10, "cost": null, "price": 148000, "buyDate": "2026-09-05", "exp": "۱۴۰۶/۱۰/۰۸", "warn": null}, {"id": "L0050", "code": "K0050", "qty": 13, "remaining": 13, "cost": null, "price": 148000, "buyDate": "2026-09-05", "exp": "۱۴۰۶/۰۹/۲۲", "warn": null}, {"id": "L0051", "code": "K0051", "qty": 4, "remaining": 4, "cost": null, "price": 148000, "buyDate": "2026-09-05", "exp": "۱۴۰۶/۰۶/۰۵", "warn": null}, {"id": "L0052", "code": "K0052", "qty": 3, "remaining": 3, "cost": null, "price": 116000, "buyDate": "2026-09-05", "exp": "۱۴۰۶/۰۴/۰۲", "warn": null}, {"id": "L0053", "code": "K0053", "qty": 10, "remaining": 10, "cost": null, "price": 127000, "buyDate": "2026-09-05", "exp": "۱۴۰۶/۰۶/۱۱", "warn": null}, {"id": "L0054", "code": "K0054", "qty": 4, "remaining": 4, "cost": null, "price": 70000, "buyDate": "2026-09-05", "exp": "۱۴۰۶/۰۷/۲۳", "warn": null}, {"id": "L0055", "code": "K0055", "qty": 1, "remaining": 1, "cost": null, "price": 90000, "buyDate": "2026-09-05", "exp": "۱۴۰۶/۰۶/۲۴", "warn": null}, {"id": "L0056", "code": "K0056", "qty": 2, "remaining": 2, "cost": null, "price": 275000, "buyDate": "2026-09-05", "exp": "۱۴۰۶/۰۳/۰۹", "warn": null}, {"id": "L0057", "code": "K0057", "qty": 9, "remaining": 9, "cost": null, "price": 319000, "buyDate": "2026-09-05", "exp": "۱۴۰۷/۰۳/۱۰", "warn": null}, {"id": "L0058", "code": "K0058", "qty": 9, "remaining": 9, "cost": null, "price": 294000, "buyDate": "2026-09-05", "exp": "۱۴۰۷/۰۲/۰۶", "warn": null}, {"id": "L0059", "code": "K0059", "qty": 6, "remaining": 6, "cost": null, "price": 149000, "buyDate": "2026-09-05", "exp": "۱۴۰۷/۰۲/۰۹", "warn": null}, {"id": "L0060", "code": "K0060", "qty": 7, "remaining": 7, "cost": null, "price": 149000, "buyDate": "2026-09-05", "exp": "۱۴۰۷/۰۲/۱۱", "warn": null}, {"id": "L0061", "code": "K0061", "qty": 8, "remaining": 8, "cost": null, "price": 149000, "buyDate": "2026-09-05", "exp": "۱۴۰۷/۰۱/۲۸", "warn": null}, {"id": "L0062", "code": "K0062", "qty": 6, "remaining": 6, "cost": null, "price": 329000, "buyDate": "2026-09-05", "exp": "۱۴۰۷/۰۳/۱۲", "warn": null}, {"id": "L0063", "code": "K0063", "qty": 31, "remaining": 31, "cost": null, "price": 179000, "buyDate": "2026-09-05", "exp": "۱۴۰۷/۰۱/۲۱", "warn": null}, {"id": "L0064", "code": "K0064", "qty": 14, "remaining": 14, "cost": null, "price": 149000, "buyDate": "2026-09-05", "exp": "۱۴۰۵/۰۹/۱۹", "warn": null}, {"id": "L0065", "code": "K0065", "qty": 14, "remaining": 14, "cost": null, "price": 154000, "buyDate": "2026-09-05", "exp": "۱۴۰۵/۰۹/۱۲", "warn": null}, {"id": "L0066", "code": "K0066", "qty": 2, "remaining": 2, "cost": null, "price": 190000, "buyDate": "2026-09-05", "exp": "۱۴۰۶/۰۲/۰۲", "warn": null}, {"id": "L0067", "code": "K0067", "qty": 11, "remaining": 11, "cost": null, "price": 215000, "buyDate": "2026-09-05", "exp": "۱۴۰۶/۰۴/۰۸", "warn": null}, {"id": "L0068", "code": "K0068", "qty": 42, "remaining": 42, "cost": null, "price": 185000, "buyDate": "2026-09-05", "exp": "۱۴۰۷/۰۱/۰۱", "warn": null}, {"id": "L0069", "code": "K0069", "qty": 20, "remaining": 20, "cost": null, "price": 107000, "buyDate": "2026-09-05", "exp": "۱۴۰۷/۰۲/۲۴", "warn": null}, {"id": "L0070", "code": "K0070", "qty": 17, "remaining": 17, "cost": null, "price": 160000, "buyDate": "2026-09-05", "exp": "۱۴۰۷/۰۳/۰۲", "warn": null}, {"id": "L0071", "code": "K0071", "qty": 56, "remaining": 56, "cost": null, "price": 50000, "buyDate": "2026-09-05", "exp": null, "warn": null}, {"id": "L0072", "code": "K0072", "qty": 14, "remaining": 14, "cost": null, "price": 60000, "buyDate": "2026-09-05", "exp": null, "warn": null}], "sales": [], "settings": {"currency": "تومان"}};
let db=JSON.parse(localStorage.getItem('store_full_v2')||'null')||structuredClone(seed);
// First-run data recovery: if an older build saved an empty database, restore the bundled product/inventory seed.
if((!Array.isArray(db.products)||db.products.length===0) && !localStorage.getItem('store_full_v2_user_cleared')){
  db=structuredClone(seed);
}
if(!Array.isArray(db.sales))db.sales=[];if(!Array.isArray(db.buys))db.buys=[];if(!Array.isArray(db.layers))db.layers=[];
if(!db.buys) db.buys=[];
let sectionHistory=[],currentCategory=null,manageMode='sales';
const fa=n=>String(n??0).replace(/\d/g,d=>'۰۱۲۳۴۵۶۷۸۹'[d]);
const toman=n=>(Math.round(n||0)).toLocaleString('fa-IR')+' تومان';
const save=()=>localStorage.setItem('store_full_v2',JSON.stringify(db));
const categoryDefs=[
 ['🍯','عسل','عسل'],['🍜','رشته','رشته'],['🍓','مربا','مربا'],['🌿','عرقیات','عرق'],['🧄','سیر','سیر'],['🥒','ترشی','ترشی'],['🫒','زیتون','زیتون'],['🥫','کنسرو','کنسرو'],['🍅','سس','سس'],['🍋','آبلیمو','آبلیمو'],['🌹','گلاب','گلاب'],['🍇','شیره','شیره'],['🥣','ارده و حلوا','ارده|حلوا'],['🥜','کره بادام‌زمینی','کره بادام'],['🍫','فرمند','فرمند'],['🍬','مرداس','مرداس'],['🍪','تروبیکا','تروبیکا'],['🍪','گود دی','گود دی']
];
function categoryOf(p){const n=p.name;const d=categoryDefs.find(x=>x[2].split('|').some(k=>n.includes(k)));return d?d[1]:'سایر';}
function emojiOf(cat){return categoryDefs.find(x=>x[1]===cat)?.[0]||'📦';}
function show(id,push=true){const active=document.querySelector('.section.active')?.id;if(push&&active&&active!==id) sectionHistory.push(active);document.querySelectorAll('.section').forEach(x=>x.classList.remove('active'));document.getElementById(id).classList.add('active');document.querySelectorAll('.nav').forEach(n=>n.classList.toggle('active',n.dataset.target===id));if(id!=='products')currentCategory=null;refresh();}
function goBack(){if(currentCategory){currentCategory=null;document.getElementById('filter').value='';renderProducts();return;}const prev=sectionHistory.pop();if(prev&&document.getElementById(prev)){show(prev,false);return;}show('home',false);}
function msg(id,t){document.getElementById(id).textContent=t}
function findP(q){q=(q||'').trim();if(!q)return null;return db.products.find(p=>p.name===q||p.code===q)||db.products.find(p=>p.name.includes(q));}
function registerBuy(){let name=document.getElementById('buyProduct').value.trim(),qty=+document.getElementById('buyQty').value;if(!name||qty<=0)return msg('buyMsg','نام کالا و تعداد معتبر لازم است.');let p=findP(name);if(!p){p={code:'K'+Date.now(),name,unit:'عدد',min:0,defaultWarn:null};db.products.push(p);}let cost=document.getElementById('buyCost').value===''?null:+document.getElementById('buyCost').value;let price=document.getElementById('buyPrice').value===''?null:+document.getElementById('buyPrice').value;let warn=document.getElementById('buyWarn').value===''?null:+document.getElementById('buyWarn').value;const newLayer={id:'L'+Date.now(),code:p.code,qty,remaining:qty,cost,price,buyDate:new Date().toISOString().slice(0,10),exp:document.getElementById('buyExp').value.trim(),warn};let insertAt=-1;db.layers.forEach((l,i)=>{if(l.code===p.code)insertAt=i;});if(insertAt>=0)db.layers.splice(insertAt+1,0,newLayer);else db.layers.push(newLayer);db.buys.push({id:'B'+Date.now(),layerId:newLayer.id,code:p.code,qty,cost,price,exp:newLayer.exp,warn,date:new Date().toISOString()});save();msg('buyMsg','لایه مستقل ثبت شد: '+newLayer.id);refresh();}
let saleCart=[];
function cartParts(item){let layers=db.layers.filter(l=>l.code===item.code&&l.remaining>0),need=item.qty,parts=[];for(const l of layers){if(!need)break;let take=Math.min(need,l.remaining);parts.push({layer:l.id,qty:take,cost:l.cost,price:item.price==null?l.price:item.price});need-=take;}return need?null:parts;}
function renderSaleCart(){let el=document.getElementById('saleCart');if(!el)return;if(!saleCart.length){el.innerHTML='<strong>سبد مشتری خالی است.</strong>';return;}let total=saleCart.reduce((a,x)=>a+x.qty*x.price,0);let customer=saleCart[0]&&((saleCart[0].customerName||saleCart[0].customerPhone)?'<div class="notice" style="font-size:15px;margin:10px 0"><strong>مشتری:</strong> '+esc2(saleCart[0].customerName||'بدون نام')+(saleCart[0].customerPhone?' — '+esc2(saleCart[0].customerPhone):'')+'</div>':'');el.innerHTML='<strong style="font-size:20px">سبد مشتری</strong>'+customer+'<div class="muted">'+fa(saleCart.length)+' قلم — جمع: <strong style="font-size:27px">'+toman(total)+'</strong></div>'+saleCart.map((x,i)=>'<div class="line"><div class="row"><strong>'+esc2(x.name)+'</strong><span style="font-size:17px;font-weight:800">'+fa(x.qty)+' × '+toman(x.price)+'</span></div><div class="muted">مبلغ: '+toman(x.qty*x.price)+' — '+(x.profitKnown?'سود: '+toman(x.profit):'سود: نامعلوم')+'</div><button class="btn" onclick="removeSaleCart('+i+')">حذف</button> <button class="btn" onclick="editSaleCart('+i+')">ویرایش</button></div>').join('');}
function addSaleToCart(){let rawProduct=document.getElementById('saleProduct').value, p=findP(rawProduct),qty=+document.getElementById('saleQty').value,raw=document.getElementById('salePrice').value;if(!rawProduct.trim())return msg('saleMsg','ابتدا کالا را انتخاب کنید.');if(!p||qty<=0)return msg('saleMsg','کالا و تعداد معتبر وارد کن.');let price=raw===''?null:+raw,item={code:p.code,name:p.name,qty,price,customerName:(document.getElementById('customerName')?.value||'').trim(),customerPhone:(document.getElementById('customerPhone')?.value||'').trim()};let parts=cartParts(item);if(!parts)return msg('saleMsg','موجودی کافی نیست. موجودی فعلی: '+fa(qty));item.price=parts[0].price;item.parts=parts;item.profitKnown=parts.every(x=>x.cost!=null);item.profit=parts.reduce((a,x)=>a+(x.cost==null?0:(x.price-x.cost)*x.qty),0);saleCart.push(item);document.getElementById('saleProduct').value='';document.getElementById('saleQty').value=1;document.getElementById('salePrice').value='';msg('saleMsg','همان کالای انتخاب‌شده به سبد مشتری اضافه شد.');renderSaleCart();}
function removeSaleCart(i){saleCart.splice(i,1);renderSaleCart();}
function editSaleCart(i){let x=saleCart[i],q=prompt('تعداد',String(x.qty));if(q===null)return;q=+q;if(!(q>0))return;let pr=prompt('قیمت فروش',String(x.price));if(pr===null)return;pr=+pr;if(!(pr>=0))return;let item={...x,qty:q,price:pr},parts=cartParts(item);if(!parts)return alert('موجودی کافی نیست.');item.parts=parts;item.profitKnown=parts.every(z=>z.cost!=null);item.profit=parts.reduce((a,z)=>a+(z.cost==null?0:(z.price-z.cost)*z.qty),0);saleCart[i]=item;renderSaleCart();}
function confirmSaleCart(){if(!saleCart.length)return msg('saleMsg','سبد مشتری خالی است. ابتدا یک کالا انتخاب و به سبد اضافه کن.');for(const x of saleCart){let parts=cartParts(x);if(!parts)return msg('saleMsg','موجودی یکی از کالاهای سبد تغییر کرده است. دوباره بررسی کن.');}let now=new Date().toISOString(),invoiceId='F'+Date.now()+Math.random().toString(36).slice(2,6);saleCart.forEach(x=>{x.parts.forEach(z=>{let l=db.layers.find(l=>l.id===z.layer);if(l)l.remaining-=z.qty});db.sales.push({id:'S'+Date.now()+Math.random().toString(36).slice(2,6),code:x.code,qty:x.qty,price:x.price,parts:x.parts,profit:x.profit,profitKnown:x.profitKnown,customerName:x.customerName||'',customerPhone:x.customerPhone||'',invoiceId,date:now,voided:false});});let n=saleCart.length;saleCart=[];save();renderSaleCart();msg('saleMsg','فروش نهایی با '+fa(n)+' قلم ثبت شد.');refresh();}
function registerSale(){let p=findP(document.getElementById('saleProduct').value),qty=+document.getElementById('saleQty').value;let custom=document.getElementById('salePrice').value;if(!p||qty<=0)return msg('saleMsg','کالا و تعداد معتبر وارد کن.');let layers=db.layers.filter(l=>l.code===p.code&&l.remaining>0),need=qty,parts=[];for(const l of layers){if(!need)break;let take=Math.min(need,l.remaining);parts.push({layer:l.id,qty:take,cost:l.cost,price:custom===''?l.price:+custom});need-=take;}if(need)return msg('saleMsg','موجودی کافی نیست. موجودی فعلی: '+fa(qty-need));parts.forEach(x=>{db.layers.find(l=>l.id===x.layer).remaining-=x.qty});const profitKnown=parts.every(x=>x.cost!=null),profit=parts.reduce((a,x)=>a+(x.cost==null?0:(x.price-x.cost)*x.qty),0);db.sales.push({id:'S'+Date.now(),code:p.code,qty,price:parts[0].price,parts,profit,profitKnown,date:new Date().toISOString(),voided:false});save();msg('saleMsg','فروش ثبت شد. '+(profitKnown?'سود: '+toman(profit):'قیمت خرید بعضی لایه‌ها نامعلوم است.'));refresh();}
function voidSale(id){let s=db.sales.find(x=>x.id===id);if(!s||s.voided)return;if(!confirm('این فروش ابطال شود؟'))return;s.parts.forEach(x=>{let l=db.layers.find(l=>l.id===x.layer);if(l)l.remaining+=x.qty});s.voided=true;s.voidedAt=new Date().toISOString();save();refresh();}
function editBuy(id){const b=db.buys.find(x=>x.id===id);if(!b)return;const l=db.layers.find(x=>x.id===b.layerId);if(!l)return;let q=prompt('تعداد خرید',String(b.qty));if(q===null)return;q=+q;if(!(q>0))return alert('تعداد معتبر نیست.');let c=prompt('قیمت خرید',b.cost==null?'':String(b.cost));if(c===null)return;let cost=c===''?null:+c;let pr=prompt('قیمت فروش',b.price==null?'':String(b.price));if(pr===null)return;let price=pr===''?null:+pr;if(l.remaining!==l.qty){if(!confirm('این لایه بخشی مصرف شده است. اصلاح تعداد/قیمت ممکن است روی موجودی و سود اثر بگذارد. ادامه می‌دهید؟'))return;}l.qty=q;l.remaining=Math.max(0,q-(b.qty-l.remaining));l.cost=cost;l.price=price;b.qty=q;b.cost=cost;b.price=price;b.editedAt=new Date().toISOString();save();refresh();}
function editProduct(code){let p=db.products.find(x=>x.code===code);if(!p)return;let name=prompt('نام کالا',p.name);if(name!==null&&name.trim()){p.name=name.trim();save();refresh();}}
function renderProducts(){
  const q=(document.getElementById('filter')?.value||'').trim();
  renderCategoryManager();
  const list=document.getElementById('productList'),catList=document.getElementById('categoryList');
  if(!list)return;
  if(!q&&!currentCategory){
    const groups={}; db.products.forEach(p=>{const c=manualCat(p);(groups[c]??=[]).push(p);});
    catList.innerHTML='<div class="category-grid">'+Object.entries(groups).map(([c,ps])=>`<div class="category-card" onclick="openCategory('${String(c).replace(/'/g,"\\'")}')"><span class="emoji">${esc2(emojiOf(c))}</span><strong>${esc2(c)}</strong><span>${fa(ps.length)} کالا ›</span></div>`).join('')+'</div>';
    list.innerHTML='';
  }else{
    catList.innerHTML=currentCategory&&!q?`<div class="category-card" style="margin-bottom:9px;cursor:pointer" onclick="currentCategory=null;renderProducts()"><span class="emoji">↩️</span><strong>بازگشت به دسته‌ها</strong><span>${esc2(currentCategory)}</span></div>`:'';
    let arr=db.products.filter(p=>!q||p.name.includes(q)||p.code.includes(q));
    if(currentCategory)arr=arr.filter(p=>manualCat(p)===currentCategory);
    list.innerHTML=arr.map(p=>{const st=db.layers.filter(l=>l.code===p.code).reduce((a,l)=>a+l.remaining,0);const cats=db.manualCategories||[];return `<div class="item" onclick="selectProductFromSearch('${String(p.code).replace(/'/g,"\\'")}')"><div class="row"><strong class="product-name">${esc2(p.name)}</strong><span class="badge">${esc2(p.code)}</span></div><div class="muted stock-text">موجودی: ${fa(st)} ${p.min?' — حداقل: '+fa(p.min):''}</div><div class="product-actions" style="margin-top:9px"><div>دسته: <strong>${esc2(manualCat(p))}</strong></div><select onclick="event.stopPropagation()" onchange="changeProductCategory('${String(p.code).replace(/'/g,"\\'")}',this.value)"><option value="">بدون دسته</option>${cats.map(c=>`<option value="${c.id}" ${db.categoryOverrides[p.code]===c.id?'selected':''}>${esc2(c.name)}</option>`).join('')}</select></div></div>`}).join('')||'<div class="notice">کالایی پیدا نشد.</div>';
  }
  document.querySelectorAll('#productNames,#productNames2').forEach(dl=>dl.innerHTML=db.products.map(p=>`<option value="${esc2(p.name)}">${esc2(p.code)}</option>`).join(''));
  updateSaleCategoryOptions();
}
function openCategory(c){currentCategory=c;document.getElementById('filter').value='';renderProducts();}
function renderAlerts(){let a=[];db.products.forEach(p=>{let st=db.layers.filter(l=>l.code===p.code).reduce((x,l)=>x+l.remaining,0);if(p.min>0&&st<=p.min)a.push(`<div class="item dangerbg"><strong>کمبود: ${p.name}</strong><div class="muted">موجودی ${fa(st)} — حداقل ${fa(p.min)}</div></div>`);db.layers.filter(l=>l.code===p.code&&l.remaining>0&&l.exp&&l.warn!==null).forEach(l=>{let days=jalaliDaysFromToday(l.exp);if(days!==null&&days<=l.warn)a.push(`<div class="item warn"><strong>نزدیک انقضا: ${p.name}</strong><div class="muted">لایه ${l.id} — ${l.exp} — حدود ${fa(days)} روز</div></div>`)})});document.getElementById('alertList').innerHTML=a.join('')||'<div class="notice">هشداری وجود ندارد.</div>';document.getElementById('alertCount').textContent=fa(a.length);}
function jalaliToGregorian(jy,jm,jd){let gy=jy+621,days=(jy-979)*365+Math.floor((jy-979)/33)*8+Math.floor(((jy-979)%33+3)/4)+79;for(let i=1;i<jm;i++)days+=i<=6?31:30;days+=jd-1;let gdays=days-80,gy2=1600+400*Math.floor(gdays/146097);gdays%=146097;if(gdays>=36525){gy2+=100*Math.floor(--gdays/36524);gdays%=36524;if(gdays>=365)gdays++;}gy2+=4*Math.floor(gdays/1461);gdays%=1461;if(gdays>=366){gy2+=Math.floor((gdays-1)/365);gdays=(gdays-1)%365;}let gd=gdays+1,gm;for(gm=1;gm<12&&gd>(gm==2?(gy2%4==0&&(gy2%100!=0||gy2%400==0)?29:28):[4,6,9,11].includes(gm)?30:31);gm++)gd-=(gm==2?(gy2%4==0&&(gy2%100!=0||gy2%400==0)?29:28):[4,6,9,11].includes(gm)?30:31);return new Date(gy2,gm-1,gd);}
function jalaliDaysFromToday(str){let m=str.replace(/[۰-۹]/g,d=>'۰۱۲۳۴۵۶۷۸۹'.indexOf(d)).match(/(\d{4})[\/-](\d{1,2})[\/-](\d{1,2})/);if(!m)return null;return Math.ceil((jalaliToGregorian(+m[1],+m[2],+m[3])-new Date())/86400000);}
function reportByProduct(){let m={};db.sales.filter(s=>!s.voided).forEach(s=>{let p=db.products.find(p=>p.code===s.code),x=m[s.code]||{name:p?.name||s.code,qty:0,sales:0,profit:0,known:true};x.qty+=s.qty;x.sales+=s.qty*s.price;x.profit+=s.profit;x.known=x.known&&s.profitKnown;m[s.code]=x});document.getElementById('reportResult').innerHTML=Object.values(m).map(x=>`<div class="item"><strong>${x.name}</strong><div class="muted">تعداد ${fa(x.qty)} — فروش ${toman(x.sales)} — سود ${x.known?toman(x.profit):'نامعلوم'}</div></div>`).join('')||'<div class="notice">فروشی ثبت نشده است.</div>';}
function reportLayers(){document.getElementById('reportResult').innerHTML=db.layers.map(l=>{let p=db.products.find(p=>p.code===l.code);return `<div class="item"><strong>${p?.name||l.code}</strong><div class="muted">${l.id} — باقی‌مانده ${fa(l.remaining)} — خرید ${l.cost==null?'نامعلوم':toman(l.cost)} — فروش ${l.price==null?'نامشخص':toman(l.price)} — انقضا ${l.exp||'ندارد'}</div></div>`}).join('')}
function reportToday(){reportPeriod('today','فروش امروز');}
function reportInventory(){let groups={};let total=0,unknown=0;db.layers.forEach(l=>{if(!l.remaining)return;let p=db.products.find(p=>p.code===l.code),c=categoryOf(p||{name:''});groups[c]=(groups[c]||0)+(l.cost!=null?l.remaining*l.cost:0);if(l.cost!=null)total+=l.remaining*l.cost;else unknown+=l.remaining});let html=`<div class="item"><strong>ارزش کل موجودی</strong><div class="value">${toman(total)}</div>${unknown?`<div class="muted">${fa(unknown)} واحد دارای قیمت خرید نامعلوم است.</div>`:''}</div>`;html+=Object.entries(groups).sort((a,b)=>b[1]-a[1]).map(([c,v])=>`<div class="item"><div class="row"><strong>${emojiOf(c)} ${c}</strong><span class="badge">ارزش موجودی</span></div><div class="value">${toman(v)}</div></div>`).join('');document.getElementById('reportResult').innerHTML=html;}
function utf8ToB64(str){const bytes=new TextEncoder().encode(str);let bin='';for(let i=0;i<bytes.length;i+=0x8000)bin+=String.fromCharCode(...bytes.subarray(i,i+0x8000));return btoa(bin);}
function b64ToUtf8(b64){const bin=atob(b64);const bytes=new Uint8Array(bin.length);for(let i=0;i<bin.length;i++)bytes[i]=bin.charCodeAt(i);return new TextDecoder().decode(bytes);}
async function sha256Hex(text){const buf=await crypto.subtle.digest('SHA-256',new TextEncoder().encode(text));return Array.from(new Uint8Array(buf)).map(x=>x.toString(16).padStart(2,'0')).join('');}
async function backup(){try{const payload=JSON.stringify({format:'PASHMAK-BACKUP',version:1,createdAt:new Date().toISOString(),data:db});const encoded=utf8ToB64(payload);const hash=await sha256Hex(encoded);const fileText='PASHMAK-BACKUP-V1\n'+hash+'\n'+encoded;const b=new Blob([fileText],{type:'application/octet-stream'}),a=document.createElement('a');a.href=URL.createObjectURL(b);a.download='پشتیبان_فروشگاه.pashbak';a.click();setTimeout(()=>URL.revokeObjectURL(a.href),1000);alert('پشتیبان دستی با موفقیت ساخته شد.');}catch(e){alert('ساخت پشتیبان انجام نشد.');}}
async function restoreBackup(e){const f=e.target.files[0];e.target.value='';if(!f)return;if(!confirm('این فایل می‌تواند اطلاعات فعلی فروشگاه را جایگزین کند.\n\nقبل از بازیابی مطمئن شوید فایل متعلق به همین فروشگاه و نسخه موردنظر شماست.\n\nادامه می‌دهید؟'))return;try{const text=await f.text();const lines=text.split('\n');if(lines.length<3||lines[0].trim()!=='PASHMAK-BACKUP-V1')throw 0;const expected=lines[1].trim(),encoded=lines.slice(2).join('').trim();if(!encoded||!/^[0-9a-f]{64}$/i.test(expected))throw 0;const actual=await sha256Hex(encoded);if(actual.toLowerCase()!==expected.toLowerCase())throw new Error('hash');const obj=JSON.parse(b64ToUtf8(encoded));if(obj.format!=='PASHMAK-BACKUP'||obj.version!==1||!obj.data||!Array.isArray(obj.data.products)||!Array.isArray(obj.data.layers)||!Array.isArray(obj.data.sales))throw 0;db=obj.data;if(!db.buys)db.buys=[];save();refresh();alert('بازیابی پشتیبان با موفقیت انجام شد.');}catch(err){alert(err&&err.message==='hash'?'فایل پشتیبان تغییر کرده یا خراب شده است.':'فایل پشتیبان معتبر نیست.');}}
function loadJson(e){let f=e.target.files[0];if(!f)return;let r=new FileReader();r.onload=()=>{try{let x=JSON.parse(r.result);if(!x.products||!x.layers||!x.sales)throw 0;db=x;if(!db.buys)db.buys=[];save();refresh();alert('بازیابی/ورود موفق بود.')}catch(_){alert('فایل معتبر نیست.')}};r.readAsText(f);e.target.value='';}
function resetApp(){const first=confirm('آیا می‌خواهید کل داده‌های سیستم پاک شود؟');if(!first){show('manage',false);return;}const second=confirm('مطمئنید می‌خواهید تمام داده‌های سیستم پاک شود؟');if(!second){show('manage',false);return;}localStorage.setItem('store_full_v2_deleted_backup',JSON.stringify(db));db={products:[],layers:[],sales:[],buys:[],settings:{currency:'تومان'}};localStorage.setItem('store_full_v2_user_cleared','1');save();alert('تمام داده‌ها پاک شد.\n\nآخرین اطلاعات در نسخه پشتیبان داخلی قابل بازگردانی است.');show('manage',false);}
function restoreLastClearedData(){const raw=localStorage.getItem('store_full_v2_deleted_backup');if(!raw){alert('نسخه‌ای برای بازگردانی وجود ندارد.');return;}if(!confirm('آیا می‌خواهید آخرین داده‌های پاک‌شده بازگردانی شوند؟')){show('manage',false);return;}try{db=JSON.parse(raw);if(!db.buys)db.buys=[];save();localStorage.removeItem('store_full_v2_deleted_backup');localStorage.removeItem('store_full_v2_user_cleared');alert('داده‌ها با موفقیت بازگردانی شدند.');show('manage',false);}catch(e){alert('بازگردانی انجام نشد.');}}
function renderClearRecovery(){const box=document.getElementById('clearRecovery');if(!box)return;box.innerHTML=localStorage.getItem('store_full_v2_deleted_backup')?'<div class="clear-recovery"><b>🛡️ نسخه پشتیبان پاکسازی</b><div>آخرین داده‌های پاک‌شده هنوز قابل بازگردانی هستند.</div><button class="btn primary full" onclick="restoreLastClearedData()">↩️ بازگردانی داده‌های پاک‌شده</button></div>':'';}
function setManageMode(mode){manageMode=mode;document.querySelectorAll('.manage-tab').forEach((b,i)=>b.classList.toggle('active',(mode==='sales'&&i===0)||(mode==='buys'&&i===1)));renderManage();}
function toJalaliParts(date){const g=new Date(date);let gy=g.getFullYear(),gm=g.getMonth()+1,gd=g.getDate();let gy2=gy-1600,gm2=gm-1,gd2=gd-1;let gDayNo=365*gy2+Math.floor((gy2+3)/4)-Math.floor((gy2+99)/100)+Math.floor((gy2+399)/400);const gdm=[0,31,59,90,120,151,181,212,243,273,304,334];gDayNo+=gdm[gm2]+gd2;if(gm>2&&((gy%4===0&&gy%100!==0)||gy%400===0))gDayNo++;let jDayNo=gDayNo-79;let jNp=Math.floor(jDayNo/12053);jDayNo%=12053;let jy=979+33*jNp+4*Math.floor(jDayNo/1461);jDayNo%=1461;if(jDayNo>=366){jy+=Math.floor((jDayNo-1)/365);jDayNo=(jDayNo-1)%365;}let jm=jDayNo<186?1+Math.floor(jDayNo/31):7+Math.floor((jDayNo-186)/30);let jd=1+(jDayNo<186?jDayNo%31:(jDayNo-186)%30);return {jy,jm,jd};}
function jalaliDateKey(iso){const j=toJalaliParts(iso);return `${j.jy}/${String(j.jm).padStart(2,'0')}/${String(j.jd).padStart(2,'0')}`;}
function dayKey(iso){return new Date(iso).toLocaleDateString('fa-IR-u-ca-persian');}
function jalaliNow(){return toJalaliParts(new Date());}
function jalaliWeekStart(j){const g=new Date(new Date().getFullYear(),new Date().getMonth(),new Date().getDate());const dow=(g.getDay()+1)%7; const d=new Date(g); d.setDate(g.getDate()-dow); return d;}
function periodSales(kind){const now=jalaliNow();return db.sales.filter(s=>{if(s.voided)return false;const j=toJalaliParts(s.date);if(kind==='today'){const tj=toJalaliParts(new Date());return j.jy===tj.jy&&j.jm===tj.jm&&j.jd===tj.jd;}if(kind==='month')return j.jy===now.jy&&j.jm===now.jm;if(kind==='week'){const start=jalaliWeekStart(new Date());const end=new Date(start);end.setDate(start.getDate()+7);const t=new Date(s.date);return t>=start&&t<end;}return false;});}
function reportPeriod(kind,label){const a=periodSales(kind),total=a.reduce((x,s)=>x+s.qty*s.price,0),profitKnown=a.every(s=>s.profitKnown!==false),profit=a.reduce((x,s)=>x+(s.profit||0),0),invoiceCount=new Set(a.map(s=>s.invoiceId||s.id)).size;let g={};a.forEach(s=>{let p=db.products.find(p=>p.code===s.code),n=p?.name||s.code;if(!g[n])g[n]={qty:0,sales:0,profit:0,known:true};g[n].qty+=s.qty;g[n].sales+=s.qty*s.price;if(s.profitKnown===false)g[n].known=false;else g[n].profit+=s.profit||0;});let details=Object.entries(g).map(([n,x])=>`<div class="item"><div class="row"><strong>${n}</strong><span class="badge">${fa(x.qty)} عدد</span></div><div class="muted">فروش: ${toman(x.sales)} — سود: ${x.known?toman(x.profit):'نامعلوم'}</div></div>`).join('');document.getElementById('reportResult').innerHTML=`<div class="report-card"><div class="report-title">${label}</div><div class="report-main">فروش: ${toman(total)}</div><div class="report-meta">سود: ${profitKnown?toman(profit):'بخشی از سود نامعلوم است'} — ${fa(invoiceCount)} فاکتور</div></div>${details||'<div class="notice">فروشی ثبت نشده است.</div>'}`;}
function reportWeekly(){reportPeriod('week','فروش این هفته');}
function reportMonthly(){reportPeriod('month','فروش این ماه');}
function reportWeeklyProfit(){const a=periodSales('week'),g={};a.forEach(s=>{const p=db.products.find(p=>p.code===s.code),n=p?.name||s.code;if(!g[n])g[n]={qty:0,profit:0,known:true};g[n].qty+=s.qty;if(s.profitKnown===false)g[n].known=false;else g[n].profit+=s.profit||0;});document.getElementById('reportResult').innerHTML=`<div class="item"><strong>سود هفتگی — هر کالا</strong></div>`+Object.entries(g).map(([n,x])=>`<div class="item"><div class="row"><strong>${n}</strong><span class="badge">${fa(x.qty)} عدد</span></div><div class="value">${x.known?toman(x.profit):'سود نامعلوم'}</div></div>`).join('')||'<div class="notice">این هفته فروشی ثبت نشده است.</div>';}
function reportMonthlyProfit(){const a=periodSales('month'),g={};a.forEach(s=>{const p=db.products.find(p=>p.code===s.code),n=p?.name||s.code;if(!g[n])g[n]={qty:0,profit:0,known:true};g[n].qty+=s.qty;if(s.profitKnown===false)g[n].known=false;else g[n].profit+=s.profit||0;});document.getElementById('reportResult').innerHTML=`<div class="item"><strong>سود ماهانه — هر کالا</strong></div>`+Object.entries(g).map(([n,x])=>`<div class="item"><div class="row"><strong>${n}</strong><span class="badge">${fa(x.qty)} عدد</span></div><div class="value">${x.known?toman(x.profit):'سود نامعلوم'}</div></div>`).join('')||'<div class="notice">این ماه فروشی ثبت نشده است.</div>';}

function renderManage(){const el=document.getElementById('manageList');if(!el)return;let groups={};if(manageMode==='sales'){db.sales.slice().reverse().forEach(s=>{let d=dayKey(s.date);(groups[d]??=[]).push(s);});}else{db.buys.slice().reverse().forEach(b=>{let d=dayKey(b.date);(groups[d]??=[]).push(b);});}if(!Object.keys(groups).length){el.innerHTML='<div class="notice">سوابقی وجود ندارد.</div>';return;}el.innerHTML=Object.entries(groups).map(([d,items])=>`<div class="daily-head"><h3>${d}</h3><span class="badge">${fa(items.length)} مورد</span></div>`+items.map(x=>manageMode==='sales'?`<div class="item"><div class="row"><strong>${db.products.find(p=>p.code===x.code)?.name||x.code}</strong><span class="badge">${new Date(x.date).toLocaleTimeString('fa-IR',{hour:'2-digit',minute:'2-digit'})}</span></div><div class="muted">تعداد ${fa(x.qty)} — مبلغ ${toman(x.qty*x.price)} — ${x.voided?'ابطال شده':'فعال'}</div>${!x.voided?`<button class="btn danger full" style="margin-top:7px" onclick="voidSale('${x.id}')">ابطال فروش</button>`:''}</div>`:`<div class="item"><div class="row"><strong>${db.products.find(p=>p.code===x.code)?.name||x.code}</strong><span class="badge">${new Date(x.date).toLocaleTimeString('fa-IR',{hour:'2-digit',minute:'2-digit'})}</span></div><div class="muted">تعداد ${fa(x.qty)} — خرید ${x.cost==null?'نامعلوم':toman(x.cost)} — فروش ${x.price==null?'نامشخص':toman(x.price)}</div><button class="btn full" style="margin-top:7px" onclick="editBuy('${x.id}')">اصلاح خرید</button></div>`).join('')).join('');}
function renderDailySales(){let a=periodSales('today').sort((x,y)=>new Date(y.date)-new Date(x.date));let el=document.getElementById('dailySalesList'),count=document.getElementById('dailySaleCount');if(!el)return;let invoiceKeys=[...new Set(a.map(s=>s.invoiceId||s.id))];count.textContent=fa(invoiceKeys.length)+' فاکتور';el.innerHTML=a.map(s=>{let p=db.products.find(p=>p.code===s.code),total=s.qty*s.price,tm=new Date(s.date).toLocaleTimeString('fa-IR',{hour:'2-digit',minute:'2-digit'});return `<div class="item"><div class="row"><strong>${p?.name||s.code}</strong><span class="badge">${tm}</span></div><div class="muted">تعداد ${fa(s.qty)} — مبلغ ${toman(total)} — سود ${s.profitKnown?toman(s.profit):'نامعلوم'}</div></div>`}).join('')||'<div class="notice">امروز هنوز فروشی ثبت نشده است.</div>';}
function showTodaySales(){sectionHistory.push('home');show('todaySalesDetail',false);renderTodaySalesDetail();}
function showTodayProfit(){sectionHistory.push('home');show('todayProfitDetail',false);renderTodayProfitDetail();}
function renderTodaySalesDetail(){let d=new Date().toDateString(),a=db.sales.filter(s=>!s.voided&&new Date(s.date).toDateString()===d).sort((x,y)=>new Date(y.date)-new Date(x.date));document.getElementById('todaySalesDetailList').innerHTML=a.map(s=>{let p=db.products.find(p=>p.code===s.code);let total=s.qty*s.price,tm=new Date(s.date).toLocaleTimeString('fa-IR',{hour:'2-digit',minute:'2-digit'});return `<div class="item"><div class="row"><strong>${p?.name||s.code}</strong><span class="badge">${tm}</span></div><div class="muted">تعداد ${fa(s.qty)} — مبلغ ${toman(total)} — سود ${s.profitKnown?toman(s.profit):'نامعلوم'}</div></div>`}).join('')||'<div class="notice">امروز هنوز فروشی ثبت نشده است.</div>';}
function renderTodayProfitDetail(){let d=new Date().toDateString(),a=db.sales.filter(s=>!s.voided&&new Date(s.date).toDateString()===d),g={};a.forEach(s=>{let p=db.products.find(p=>p.code===s.code),n=p?.name||s.code;if(!g[n])g[n]={qty:0,profit:0,known:true};g[n].qty+=s.qty;if(s.profitKnown===false)g[n].known=false;else g[n].profit+=s.profit||0;});let arr=Object.entries(g);document.getElementById('todayProfitDetailList').innerHTML=arr.map(([n,x])=>`<div class="item"><div class="row"><strong>${n}</strong><span class="badge">${fa(x.qty)} عدد</span></div><div class="value">${x.known?toman(x.profit):'سود نامعلوم'}</div></div>`).join('')||'<div class="notice">امروز هنوز فروشی ثبت نشده است.</div>';}
function refresh(){let today=new Date().toDateString(),ss=db.sales.filter(s=>!s.voided&&new Date(s.date).toDateString()===today);document.getElementById('todaySales').textContent=toman(ss.reduce((a,s)=>a+s.qty*s.price,0));document.getElementById('todayProfit').textContent=toman(ss.reduce((a,s)=>a+s.profit,0));let v=0;db.layers.forEach(l=>{if(l.cost!=null)v+=l.remaining*l.cost});document.getElementById('stockValue').textContent=toman(v);renderProducts();renderAlerts();renderManage();renderDailySales();renderClearRecovery();}
refresh();

/* ===== v1.0.2 functional category/report layer ===== */
if(!Array.isArray(db.manualCategories)) db.manualCategories=[];
if(!db.categoryOverrides || typeof db.categoryOverrides!=='object') db.categoryOverrides={};
function esc2(s){return String(s??'').replace(/[&<>\"']/g,m=>({'&':'&amp;','<':'&lt;','>':'&gt;','\"':'&quot;',"'":'&#39;'}[m]||m));}
function manualCat(p){const id=db.categoryOverrides[p.code];const c=db.manualCategories.find(x=>x.id===id);return c?c.name:categoryOf(p);}
function saveCat(){save();refresh();}
function createCategory(){const v=prompt('نام دسته جدید:');if(v===null)return;const n=v.trim();if(!n)return alert('نام دسته نمی‌تواند خالی باشد.');if(db.manualCategories.some(c=>c.name.trim().toLowerCase()===n.toLowerCase()))return alert('این دسته قبلاً وجود دارد.');db.manualCategories.push({id:'CAT-'+Date.now()+'-'+Math.random().toString(36).slice(2,6),name:n});saveCat();}
function renameCategory(id){const c=db.manualCategories.find(x=>x.id===id);if(!c)return;const v=prompt('نام جدید دسته:',c.name);if(v===null)return;const n=v.trim();if(!n)return alert('نام دسته نمی‌تواند خالی باشد.');if(db.manualCategories.some(x=>x.id!==id&&x.name.trim().toLowerCase()===n.toLowerCase()))return alert('این دسته قبلاً وجود دارد.');c.name=n;saveCat();}
function deleteCategory(id){const c=db.manualCategories.find(x=>x.id===id);if(!c)return;const count=db.products.filter(p=>db.categoryOverrides[p.code]===id).length;if(!confirm(count?`این دسته ${fa(count)} کالا دارد. با حذف دسته، کالاها «بدون دسته» می‌شوند. ادامه می‌دهید؟`:'این دسته حذف شود؟'))return;db.products.forEach(p=>{if(db.categoryOverrides[p.code]===id)delete db.categoryOverrides[p.code]});db.manualCategories=db.manualCategories.filter(x=>x.id!==id);saveCat();}
function changeProductCategory(code,id){if(id)db.categoryOverrides[code]=id;else delete db.categoryOverrides[code];save();renderProducts();}
function renderCategoryManager(){const el=document.getElementById('categoryManager');if(!el)return;const cats=db.manualCategories||[];const cards=cats.map(c=>{const n=db.products.filter(p=>db.categoryOverrides[p.code]===c.id).length;return `<div class="category-card" style="padding:16px;margin-bottom:9px"><div class="row"><strong>${esc2(emojiOf(c.name))} ${esc2(c.name)}</strong><span><button class="btn edit-name-btn" onclick="renameCategory('${c.id}')">✏️</button><button class="btn edit-name-btn" onclick="deleteCategory('${c.id}')">🗑️</button></span></div><span>${fa(n)} کالا</span></div>`}).join('');el.innerHTML=`<div class="item"><div class="row"><strong>📂 دسته‌های کالا</strong><button class="btn" onclick="createCategory()">＋ ایجاد دسته جدید</button></div><div style="margin-top:9px">${cards||'<div class="muted">هنوز دسته‌ای ساخته نشده است.</div>'}</div></div>`;}
function renderProducts(){const q=(document.getElementById('filter')?.value||'').trim();const arr=db.products.filter(p=>!q||p.name.includes(q)||p.code.includes(q));renderCategoryManager();const list=document.getElementById('productList');if(!list)return;list.innerHTML=arr.map(p=>{const st=db.layers.filter(l=>l.code===p.code).reduce((a,l)=>a+l.remaining,0);const cats=db.manualCategories||[];return `<div class="item"><div class="row"><strong class="product-name">${esc2(p.name)}</strong><span class="badge">${esc2(p.code)}</span></div><div class="muted stock-text">موجودی: ${fa(st)} ${p.min?' — حداقل: '+fa(p.min):''}</div><div class="product-actions" style="margin-top:9px"><div>دسته: <strong>${esc2(manualCat(p))}</strong></div><select onchange="changeProductCategory('${String(p.code).replace(/'/g,"\\'")}',this.value)"><option value="">بدون دسته</option>${cats.map(c=>`<option value="${c.id}" ${db.categoryOverrides[p.code]===c.id?'selected':''}>${esc2(c.name)}</option>`).join('')}</select></div></div>`}).join('')||'<div class="notice">کالایی پیدا نشد.</div>';document.querySelectorAll('#productNames,#productNames2').forEach(dl=>dl.innerHTML=db.products.map(p=>`<option value="${esc2(p.name)}">${esc2(p.code)}</option>`).join(''));}
function openReportPage(type){document.getElementById('reportHome').style.display='none';document.getElementById('reportDetail').style.display='block';const b=document.getElementById('reportDetailBody');if(type==='sales')b.innerHTML='<h2>فروش</h2><div class="grid"><button class="btn" onclick="reportToday()">روزانه</button><button class="btn" onclick="reportWeekly()">هفتگی</button><button class="btn" onclick="reportMonthly()">ماهانه</button></div><div id="reportResult"></div>';else if(type==='profit')b.innerHTML='<h2>سود</h2><div class="grid"><button class="btn" onclick="reportTodayProfit()">روزانه</button><button class="btn" onclick="reportWeeklyProfit()">هفتگی</button><button class="btn" onclick="reportMonthlyProfit()">ماهانه</button></div><div id="reportResult"></div>';else if(type==='inventory'){b.innerHTML='<h2>ارزش موجودی</h2><div id="reportResult"></div>';reportInventory();}else{b.innerHTML='<h2>لایه‌ها</h2><div id="reportResult"></div>';reportLayers();}}
function closeReportPage(){document.getElementById('reportDetail').style.display='none';document.getElementById('reportHome').style.display='grid';}
function reportTodayProfit(){const a=periodSales('today');const known=a.filter(s=>s.profitKnown!==false);const p=known.reduce((x,s)=>x+(s.profit||0),0);document.getElementById('reportResult').innerHTML=`<div class="item"><strong>سود روزانه</strong><div class="value">${toman(p)}</div>${known.length<a.length?'<div class="muted">بخشی از سود نامعلوم است.</div>':''}</div>`;}
/* v1.0.2 version history */
function renderVersionHistory(){const old=document.getElementById('versionHistory');if(!old)return;old.innerHTML=`<div class="item"><div class="row"><strong>نسخه و آخرین تغییرات</strong><span class="badge">v1.0.2</span></div><button class="btn full" onclick="toggleVersionHistory()">📋 نسخه و آخرین تغییرات</button><div id="versionHistoryBody" style="display:none;margin-top:10px"><div class="notice"><strong>v1.0.2 — نسخه فعلی</strong><div class="muted">• مدیریت واقعی دسته‌ها: ایجاد، ویرایش و حذف<br>• دسته‌بندی واقعی کالاها و انتقال کالا بین دسته‌ها<br>• گزارش‌ها با ورود مرحله‌ای به هر بخش<br>• یکسان‌سازی رنگ تب فروش</div></div><div class="notice"><strong>v1.0.1</strong><div class="muted">• اصلاح FIFO و مصرف چند لایه<br>• ارزش موجودی خرید و فروش<br>• گزارش‌های روزانه، هفتگی و ماهانه<br>• سابقه فروش و پیش‌فاکتور</div></div></div></div>`;}
function toggleVersionHistory(){const e=document.getElementById('versionHistoryBody');if(e)e.style.display=e.style.display==='none'?'block':'none';}

/* ===== Final fixes v2 ===== */
function categoryListForSales(){return [...new Set(db.products.map(p=>manualCat(p)))].filter(Boolean);}
function updateSaleCategoryOptions(){const el=document.getElementById('saleCategory');if(!el)return;const cats=categoryListForSales(),cur=el.value;el.innerHTML='<option value="">همه دسته‌ها</option>'+cats.map(c=>`<option value="${esc2(c)}">${esc2(emojiOf(c))} ${esc2(c)}</option>`).join('');if(cats.includes(cur))el.value=cur;else if(cats.includes('عسل'))el.value='عسل';updateSaleProducts();}
function resetSaleCustomer(){
  ['customerName','customerPhone','saleProduct','salePrice'].forEach(id=>{const e=document.getElementById(id);if(e){e.value='';e.blur&&e.blur();}});
  const q=document.getElementById('saleQty');if(q)q.value=1;
  const results=document.getElementById('saleSearchResults');if(results){results.innerHTML='';results.style.display='none';}
  const msgEl=document.getElementById('saleMsg');if(msgEl)msgEl.textContent='فروش ثبت شد. آماده ثبت مشتری بعدی.';
  const c=document.getElementById('saleCategory');if(c){c.value='عسل';updateSaleProducts();}
  renderSaleCart();
}
const _confirmSaleCart=confirmSaleCart;confirmSaleCart=function(){
  const hadItems=saleCart.length>0;
  _confirmSaleCart();
  if(hadItems && !saleCart.length)resetSaleCustomer();
};
function createCategory(){const v=prompt('نام دسته جدید:');if(v===null)return;const n=v.trim();if(!n)return alert('نام دسته نمی‌تواند خالی باشد.');if(db.manualCategories.some(c=>c.name.trim().toLowerCase()===n.toLowerCase()))return alert('این دسته قبلاً وجود دارد.');const icon=prompt('ایموجی/آیکون دسته را وارد کن (مثلاً ☕ برای قهوه):','📦');db.manualCategories.push({id:'CAT-'+Date.now()+'-'+Math.random().toString(36).slice(2,6),name:n,icon:(icon||'📦').trim()});saveCat();}
function renameCategory(id){const c=db.manualCategories.find(x=>x.id===id);if(!c)return;const v=prompt('نام جدید دسته:',c.name);if(v===null)return;const n=v.trim();if(!n)return alert('نام دسته نمی‌تواند خالی باشد.');if(db.manualCategories.some(x=>x.id!==id&&x.name.trim().toLowerCase()===n.toLowerCase()))return alert('این دسته قبلاً وجود دارد.');c.name=n;saveCat();}
function changeCategoryIcon(id){const c=db.manualCategories.find(x=>x.id===id);if(!c)return;const v=prompt('ایموجی/آیکون جدید دسته:',c.icon||'📦');if(v===null)return;c.icon=v.trim()||'📦';saveCat();}
function emojiOf(cat){const c=(db.manualCategories||[]).find(x=>x.name===cat);if(c&&c.icon)return c.icon;return categoryDefs.find(x=>x[1]===cat)?.[0]||'📦';}
function categoryCardList(){
  const names=[...new Set(db.products.map(p=>manualCat(p)).filter(Boolean))];
  return names.map(name=>{const count=db.products.filter(p=>manualCat(p)===name).length;return `<div class="category-card" onclick="openCategory('${String(name).replace(/\\/g,'\\\\').replace(/'/g,"\\'")}')"><div class="category-icon">${esc2(emojiOf(name))}</div><div class="category-title">${esc2(name)}</div><div class="category-count">${fa(count)} کالا</div></div>`}).join('');
}
function renderCategoryManager(){
  const el=document.getElementById('categoryManager');if(!el)return;
  const cards=categoryCardList();
  const manual=(db.manualCategories||[]).map(c=>{const n=db.products.filter(p=>db.categoryOverrides[p.code]===c.id).length;return `<div class="item"><div class="row"><div class="category-actions"><span class="category-icon">${esc2(c.icon||'📦')}</span><strong>${esc2(c.name)}</strong></div><span><button class="btn category-icon-btn" onclick="changeCategoryIcon('${c.id}')">🖼️</button><button class="btn edit-name-btn" onclick="renameCategory('${c.id}')">✏️</button><button class="btn edit-name-btn" onclick="deleteCategory('${c.id}')">🗑️</button></span></div><span class="muted">${fa(n)} کالا</span></div>`}).join('');
  el.innerHTML=`<div class="item"><div class="row"><strong>📂 دسته‌های کالا</strong><button class="btn" onclick="createCategory()">＋ ایجاد دسته جدید</button></div><div class="category-grid" style="margin-top:10px">${cards||'<div class="notice">دسته‌ای برای نمایش وجود ندارد.</div>'}</div>${manual?'<div style="margin-top:10px"><strong>مدیریت دسته‌های سفارشی</strong>'+manual+'</div>':''}</div>`;
}
function renderProducts(){
  const q=(document.getElementById('filter')?.value||'').trim();renderCategoryManager();const list=document.getElementById('productList');if(!list)return;
  if(!q&&!currentCategory){list.innerHTML='';return;}
  let arr=db.products.filter(p=>!q||p.name.includes(q)||p.code.includes(q));if(currentCategory&&!q)arr=arr.filter(p=>manualCat(p)===currentCategory);
  const cats=db.manualCategories||[];
  const head=currentCategory&&!q?`<div class="category-card" style="margin-bottom:10px" onclick="currentCategory=null;document.getElementById('filter').value='';renderProducts()"><div class="category-icon">↩️</div><div class="category-title">بازگشت به دسته‌ها</div><div class="category-count">${esc2(currentCategory)}</div></div>`:'';
  list.innerHTML=head+arr.map(p=>{const st=db.layers.filter(l=>l.code===p.code).reduce((a,l)=>a+l.remaining,0);return `<div class="item"><div class="row"><strong class="product-name">${esc2(p.name)}</strong><span class="badge">${esc2(p.code)}</span></div><div class="muted stock-text">موجودی: ${fa(st)} ${p.min?' — حداقل: '+fa(p.min):''}</div><div class="product-actions" style="margin-top:9px"><div>دسته: <strong>${esc2(manualCat(p))}</strong></div><select onchange="changeProductCategory('${String(p.code).replace(/'/g,"\\'")}',this.value)"><option value="">بدون دسته</option>${cats.map(c=>`<option value="${c.id}" ${db.categoryOverrides[p.code]===c.id?'selected':''}>${esc2(c.name)}</option>`).join('')}</select></div></div>`}).join('')||'<div class="notice">کالایی پیدا نشد.</div>';
  document.querySelectorAll('#productNames,#productNames2').forEach(dl=>dl.innerHTML=db.products.map(p=>`<option value="${esc2(p.name)}">${esc2(p.code)}</option>`).join(''));
}
function openCategory(c){currentCategory=c;document.getElementById('filter').value='';renderProducts();}
const _renderWeeklyProfit=reportWeeklyProfit;reportWeeklyProfit=function(){_renderWeeklyProfit();const h=document.querySelector('#reportResult .item strong');if(h)h.parentElement.classList.add('report-card');};
const _renderMonthlyProfit=reportMonthlyProfit;reportMonthlyProfit=function(){_renderMonthlyProfit();const h=document.querySelector('#reportResult .item strong');if(h)h.parentElement.classList.add('report-card');};
const _renderTodayProfit=reportTodayProfit;reportTodayProfit=function(){_renderTodayProfit();const h=document.querySelector('#reportResult .item strong');if(h)h.parentElement.classList.add('report-card');};
const _openReportPage=openReportPage;openReportPage=function(type){_openReportPage(type);if(type==='profit'){const d=document.querySelector('#reportDetailBody .grid');if(d)d.className='report-period-grid';}if(type==='inventory'){const v=document.querySelector('#reportResult .value');if(v)v.classList.add('report-big-value');}};
const _refresh=refresh;refresh=function(){_refresh();updateSaleCategoryOptions();if(document.getElementById('manage')?.classList.contains('active'))renderVersionHistory();};

function addSaleToCart(){
  const rawProduct=(document.getElementById('saleProduct')?.value||'').trim();
  if(!rawProduct)return msg('saleMsg','ابتدا کالا را انتخاب کنید.');
  const p=findP(rawProduct),qty=+(document.getElementById('saleQty')?.value||0),raw=document.getElementById('salePrice')?.value||'';
  if(!p||qty<=0)return msg('saleMsg','کالا و تعداد معتبر وارد کن.');
  let price=raw===''?null:+raw;
  const firstLayer=db.layers.find(l=>l.code===p.code&&l.remaining>0&&l.price!=null);
  if(price==null && firstLayer)price=firstLayer.price;
  if(price==null)return msg('saleMsg','برای این کالا قیمت فروش ثبت نشده است.');
  const item={code:p.code,name:p.name,qty,price,customerName:(document.getElementById('customerName')?.value||'').trim(),customerPhone:(document.getElementById('customerPhone')?.value||'').trim()};
  const parts=cartParts(item); if(!parts)return msg('saleMsg','موجودی کافی نیست. موجودی فعلی: '+fa(qty));
  item.parts=parts; item.profitKnown=parts.every(x=>x.cost!=null); item.profit=parts.reduce((a,x)=>a+(x.cost==null?0:(x.price-x.cost)*x.qty),0);
  saleCart.push(item);
  document.getElementById('saleProduct').value='';document.getElementById('saleQty').value=1;document.getElementById('salePrice').value='';
  msg('saleMsg','همان کالای انتخاب‌شده به سبد مشتری اضافه شد.'); renderSaleCart();
}
function renderSaleCart(){
  const el=document.getElementById('saleCart');if(!el)return;
  if(!saleCart.length){el.innerHTML='<strong style="font-size:20px">سبد مشتری خالی است.</strong><div class="muted" style="font-size:15px;margin-top:8px">ابتدا یک کالا انتخاب و به سبد اضافه کن.</div>';return;}
  const total=saleCart.reduce((a,x)=>a+x.qty*x.price,0), c=saleCart[0]||{};
  const customer=(c.customerName||c.customerPhone)?`<div class="notice" style="font-size:16px;margin:10px 0"><strong>مشتری:</strong> ${esc2(c.customerName||'بدون نام')}${c.customerPhone?' — '+esc2(c.customerPhone):''}</div>`:'';
  el.innerHTML='<strong style="font-size:22px">سبد مشتری</strong>'+customer+`<div class="muted" style="font-size:16px;margin:8px 0">${fa(saleCart.length)} قلم — جمع: <strong style="font-size:30px">${toman(total)}</strong></div>`+saleCart.map((x,i)=>`<div class="line"><div class="row"><strong style="font-size:19px">${esc2(x.name)}</strong><span style="font-size:18px;font-weight:800">${fa(x.qty)} × ${toman(x.price)}</span></div><div class="muted" style="font-size:15px">مبلغ: ${toman(x.qty*x.price)} — ${x.profitKnown?'سود: '+toman(x.profit):'سود: نامعلوم'}</div><button class="btn" style="font-size:14px;padding:10px 14px" onclick="removeSaleCart(${i})">حذف</button> <button class="btn" style="font-size:14px;padding:10px 14px" onclick="editSaleCart(${i})">ویرایش</button></div>`).join('');
}
/* Category images: stored locally so they work offline. */
function ensureCategoryImages(){if(!db.categoryImages)db.categoryImages={};return db.categoryImages;}
function categoryVisual(name){const img=ensureCategoryImages()[name];return img?`<img class="category-image" src="${img}" alt="">`:`<span class="category-icon">${esc2(emojiOf(name))}</span>`;}
function changeCategoryImageByName(name){
  const input=document.getElementById('categoryImagePicker'); if(!input)return;
  input.dataset.category=name; input.value=''; input.click();
}
function handleCategoryImageUpload(e){
  const f=e.target.files&&e.target.files[0], name=e.target.dataset.category; if(!f||!name)return;
  if(!f.type.startsWith('image/'))return alert('لطفاً یک تصویر انتخاب کن.');
  const r=new FileReader(); r.onload=()=>{ensureCategoryImages()[name]=r.result;save();renderProducts();}; r.readAsDataURL(f);
}
function renameCategoryByName(name){
  const old=name, v=prompt('نام جدید دسته:',old); if(v===null)return; const n=v.trim(); if(!n||n===old)return;
  if(categoryListForSales().some(c=>c.trim().toLowerCase()===n.toLowerCase()))return alert('این دسته قبلاً وجود دارد.');
  const oldManual=(db.manualCategories||[]).find(c=>c.name===old);
  if(oldManual){oldManual.name=n; if(db.categoryImages&&db.categoryImages[old]){db.categoryImages[n]=db.categoryImages[old];delete db.categoryImages[old];} saveCat(); return;}
  const id='CAT-'+Date.now()+'-'+Math.random().toString(36).slice(2,6); db.manualCategories.push({id,name:n,icon:emojiOf(old)});
  db.products.filter(p=>categoryOf(p)===old).forEach(p=>db.categoryOverrides[p.code]=id);
  if(db.categoryImages&&db.categoryImages[old]){db.categoryImages[n]=db.categoryImages[old];delete db.categoryImages[old];}
  saveCat();
}
function deleteCategoryByName(name){
  const count=db.products.filter(p=>manualCat(p)===name).length;
  if(!confirm(`دسته «${name}» با ${fa(count)} کالا حذف شود؟ کالاها به «بدون دسته» منتقل می‌شوند.`))return;
  const c=(db.manualCategories||[]).find(x=>x.name===name);
  if(c){db.products.forEach(p=>{if(db.categoryOverrides[p.code]===c.id)delete db.categoryOverrides[p.code]});db.manualCategories=db.manualCategories.filter(x=>x.id!==c.id);}
  else {db.products.filter(p=>categoryOf(p)===name).forEach(p=>{const id='CAT-UNCAT'; if(!db.manualCategories.some(c=>c.id===id))db.manualCategories.push({id,name:'بدون دسته',icon:'📦'});db.categoryOverrides[p.code]=id;});}
  if(db.categoryImages)delete db.categoryImages[name]; saveCat();
}
function renderCategoryManager(){
  const el=document.getElementById('categoryManager');if(!el)return; ensureCategoryImages();
  const names=[...new Set(db.products.map(p=>manualCat(p)).filter(Boolean))];
  const cards=names.map(name=>{const count=db.products.filter(p=>manualCat(p)===name).length;return `<div class="category-card" onclick="openCategory('${String(name).replace(/\\/g,'\\\\').replace(/'/g,"\\'")}')"><div>${categoryVisual(name)}</div><div class="category-title">${esc2(name)}</div><div class="category-count">${fa(count)} کالا</div><div class="category-actions"><button class="btn category-icon-btn" onclick="event.stopPropagation();changeCategoryImageByName('${String(name).replace(/'/g,"\\'")}')">🖼️ تصویر</button><button class="btn edit-name-btn" onclick="event.stopPropagation();renameCategoryByName('${String(name).replace(/'/g,"\\'")}')">✏️</button><button class="btn edit-name-btn" onclick="event.stopPropagation();deleteCategoryByName('${String(name).replace(/'/g,"\\'")}')">🗑️</button></div></div>`}).join('');
  el.innerHTML=`<div class="item"><div class="row"><strong style="font-size:17px">📂 دسته‌های کالا</strong><button class="btn" onclick="createCategory()">＋ ایجاد دسته جدید</button></div><div class="category-grid" style="margin-top:10px">${cards||'<div class="notice">دسته‌ای برای نمایش وجود ندارد.</div>'}</div><input id="categoryImagePicker" type="file" accept="image/*" hidden onchange="handleCategoryImageUpload(event)"></div>`;
}
/* Make version/latest changes visible only in مدیریت. */
function renderVersionHistory(){const old=document.getElementById('versionHistory');if(!old)return;old.innerHTML=`<div class="item"><div class="row"><strong>نسخه و آخرین تغییرات</strong><span class="badge">v2.0.0</span></div><button class="btn full" onclick="toggleVersionHistory()">📋 نسخه و آخرین تغییرات</button><div id="versionHistoryBody" style="display:none;margin-top:10px"><div class="notice"><strong>v2.0.0 — نسخه فعلی</strong><div class="muted">• جستجوی کالا و دسته در فروش<br>• ثبت دقیق کالای انتخاب‌شده در سبد مشتری<br>• نام و شماره مشتری در فروش<br>• مدیریت دسته‌ها و تصویر دسته‌ها<br>• گزارش‌های سود روزانه، هفتگی و ماهانه</div></div></div></div>`;}


/* ===== Unified category manager: all categories support image/rename/delete/transfer ===== */
function ensureAllCategoriesManaged(){
  if(!Array.isArray(db.manualCategories))db.manualCategories=[];
  if(!db.categoryOverrides||typeof db.categoryOverrides!=='object')db.categoryOverrides={};
  const names=[...new Set((db.products||[]).map(p=>categoryOf(p)).filter(Boolean))];
  names.forEach(name=>{
    if(!db.manualCategories.some(c=>c.name===name)){
      const id='CAT-BASE-'+encodeURIComponent(name);
      db.manualCategories.push({id,name,icon:categoryDefs.find(x=>x[1]===name)?.[0]||'📦',base:true});
    }
  });
  (db.products||[]).forEach(p=>{
    if(!db.categoryOverrides[p.code]){
      const name=categoryOf(p),c=db.manualCategories.find(x=>x.name===name);
      if(c)db.categoryOverrides[p.code]=c.id;
    }
  });
}
ensureAllCategoriesManaged();
function categoryIdByName(name){return (db.manualCategories||[]).find(c=>c.name===name)?.id||null;}
function categoryNames(){return [...new Set((db.manualCategories||[]).map(c=>c.name).filter(Boolean))];}
function categoryListForSales(){return categoryNames();}
function manualCat(p){const id=db.categoryOverrides?.[p.code];const c=(db.manualCategories||[]).find(x=>x.id===id);return c?c.name:categoryOf(p);}
function createCategory(){
  const v=prompt('نام دسته جدید:');if(v===null)return;
  const n=v.trim();if(!n)return alert('نام دسته نمی‌تواند خالی باشد.');
  if(categoryNames().some(x=>x.trim().toLowerCase()===n.toLowerCase()))return alert('این دسته قبلاً وجود دارد.');
  const id='CAT-'+Date.now()+'-'+Math.random().toString(36).slice(2,8);
  const icon=prompt('ایموجی/آیکون دسته (اختیاری):','📦');
  db.manualCategories.push({id,name:n,icon:(icon||'📦').trim()});
  ensureCategoryImages(); save(); renderProducts();
  const input=document.getElementById('categoryImagePicker');
  if(input){input.dataset.category=n;setTimeout(()=>input.click(),50);}
}
function renameCategory(id){
  const c=db.manualCategories.find(x=>x.id===id);if(!c)return;
  const v=prompt('نام جدید دسته:',c.name);if(v===null)return;
  const n=v.trim();if(!n||n===c.name)return;
  if(categoryNames().some(x=>x!==c.name&&x.trim().toLowerCase()===n.toLowerCase()))return alert('این دسته قبلاً وجود دارد.');
  const old=c.name;c.name=n;
  if(db.categoryImages&&db.categoryImages[old]){db.categoryImages[n]=db.categoryImages[old];delete db.categoryImages[old];}
  save();renderProducts();
}
function changeCategoryIcon(id){const c=db.manualCategories.find(x=>x.id===id);if(!c)return;const v=prompt('ایموجی/آیکون جدید دسته:',c.icon||'📦');if(v===null)return;c.icon=v.trim()||'📦';save();renderProducts();}
function changeCategoryImageByName(name){const input=document.getElementById('categoryImagePicker');if(!input)return;input.dataset.category=name;input.value='';input.click();}
function handleCategoryImageUpload(e){
  const f=e.target.files&&e.target.files[0],name=e.target.dataset.category;if(!f||!name)return;
  if(!f.type.startsWith('image/'))return alert('لطفاً یک تصویر انتخاب کن.');
  const r=new FileReader();r.onload=()=>{ensureCategoryImages()[name]=r.result;save();renderProducts();};r.readAsDataURL(f);
}
function deleteCategory(id){
  const c=db.manualCategories.find(x=>x.id===id);if(!c)return;
  const count=db.products.filter(p=>manualCat(p)===c.name).length;
  if(!confirm(count?`دسته «${c.name}» ${fa(count)} کالا دارد. با حذف دسته، کالاها «بدون دسته» می‌شوند. ادامه می‌دهید؟`:`دسته «${c.name}» حذف شود؟`))return;
  db.products.forEach(p=>{if(db.categoryOverrides[p.code]===id)delete db.categoryOverrides[p.code]});
  db.manualCategories=db.manualCategories.filter(x=>x.id!==id);
  if(db.categoryImages)delete db.categoryImages[c.name];
  save();renderProducts();
}
function changeProductCategory(code,id){
  if(id)db.categoryOverrides[code]=id;else delete db.categoryOverrides[code];
  save();renderProducts();
}
function emojiOf(cat){const c=(db.manualCategories||[]).find(x=>x.name===cat);if(c&&c.icon)return c.icon;return categoryDefs.find(x=>x[1]===cat)?.[0]||'📦';}
function categoryVisual(name){const img=ensureCategoryImages()[name];return img?`<img class="category-image" src="${img}" alt="">`:`<span class="category-icon">${esc2(emojiOf(name))}</span>`;}
function renderCategoryManager(){
  const el=document.getElementById('categoryManager');if(!el)return;ensureCategoryImages();ensureAllCategoriesManaged();
  const cards=categoryNames().map(name=>{
    const c=categoryIdByName(name),count=db.products.filter(p=>manualCat(p)===name).length;
    return `<div class="category-card" onclick="openCategory('${String(name).replace(/\\/g,'\\\\').replace(/'/g,"\\'")}')"><div>${categoryVisual(name)}</div><div class="category-title">${esc2(name)}</div><div class="category-count">${fa(count)} کالا</div><div class="category-actions"><button class="btn category-icon-btn" onclick="event.stopPropagation();changeCategoryImageByName('${String(name).replace(/'/g,"\\'")}')">🖼️ عکس</button><button class="btn edit-name-btn" onclick="event.stopPropagation();renameCategory('${c}')">✏️ نام</button><button class="btn edit-name-btn" onclick="event.stopPropagation();deleteCategory('${c}')">🗑️ حذف</button></div></div>`;
  }).join('');
  el.innerHTML=`<div class="item"><div class="row"><strong style="font-size:17px">📂 مدیریت همه دسته‌ها</strong><button class="btn" onclick="createCategory()">＋ ایجاد دسته جدید</button></div><div class="notice">برای همه دسته‌ها: تغییر نام، تغییر عکس، حذف با تأیید و انتقال کالا بین دسته‌ها فعال است.</div><div class="category-grid" style="margin-top:10px">${cards||'<div class="notice">دسته‌ای برای نمایش وجود ندارد.</div>'}</div><input id="categoryImagePicker" type="file" accept="image/*" hidden onchange="handleCategoryImageUpload(event)"></div>`;
}

/* ===== v2.1 critical fixes: sales history, invoice counting, daily details, product recovery ===== */
function saleDateParts(s){return toJalaliParts(s.date||new Date());}
function saleDateKey(s){const j=saleDateParts(s);return `${j.jy}/${String(j.jm).padStart(2,'0')}/${String(j.jd).padStart(2,'0')}`;}
function saleTime(s){return new Date(s.date||0).toLocaleTimeString('fa-IR',{hour:'2-digit',minute:'2-digit'});}
function activeSales(){return (db.sales||[]).filter(s=>!s.voided&&s.date);}
function invoiceKey(s){return s.invoiceId||s.id;}
function groupedInvoices(list){
  const groups={};
  list.forEach(s=>{const k=invoiceKey(s);if(!groups[k])groups[k]={id:k,date:s.date,customerName:s.customerName||'',customerPhone:s.customerPhone||'',items:[]};groups[k].items.push(s);if(new Date(s.date)>new Date(groups[k].date))groups[k].date=s.date;});
  return Object.values(groups).sort((a,b)=>new Date(b.date)-new Date(a.date));
}
function showSalesHistory(){sectionHistory.push('home');show('salesHistory',false);renderSalesHistory();}
function renderSalesHistory(){
  const el=document.getElementById('salesHistoryList');if(!el)return;
  const inv=groupedInvoices(activeSales());
  if(!inv.length){el.innerHTML='<div class="notice">هنوز هیچ فاکتور فروشی ثبت نشده است.</div>';return;}
  const days={};
  inv.forEach(x=>{const d=saleDateKey(x);(days[d]??=[]).push(x);});
  el.innerHTML=Object.entries(days).map(([d,items])=>{
    const dayTitle=d.replace(/(\d{4})-(\d{2})-(\d{2})/, '$1/$2/$3');
    return `<div class="daily-head"><h3>تاریخ ${fa(dayTitle)}</h3><span class="badge">${fa(items.length)} فاکتور</span></div>`+
      items.map(x=>{const total=x.items.reduce((a,s)=>a+s.qty*s.price,0);const customer=(x.customerName||x.customerPhone)?`<div class="muted">مشتری: ${esc2(x.customerName||'بدون نام')}${x.customerPhone?' — '+esc2(x.customerPhone):''}</div>`:'';const details=x.items.map(s=>{const p=db.products.find(p=>p.code===s.code);return `<div class="line"><strong>${esc2(p?.name||s.code)}</strong><div class="muted">تعداد ${fa(s.qty)} — مبلغ ${toman(s.qty*s.price)} — سود ${s.profitKnown?toman(s.profit):'نامعلوم'}</div></div>`}).join('');return `<div class="item report-card"><div class="row"><strong>فاکتور ${esc2(x.id)}</strong><span class="badge">${saleTime(x)}</span></div>${customer}${details}<div class="report-meta">جمع فاکتور: ${toman(total)}</div></div>`;}).join('');
  }).join('');
}
function isSameLocalDay(a,b){const x=new Date(a),y=new Date(b);return x.getFullYear()===y.getFullYear()&&x.getMonth()===y.getMonth()&&x.getDate()===y.getDate();}
function salesForToday(){return activeSales().filter(s=>isSameLocalDay(s.date,new Date()));}
function renderDailySales(){
  const a=salesForToday().sort((x,y)=>new Date(y.date)-new Date(x.date));
  const el=document.getElementById('dailySalesList'),count=document.getElementById('dailySaleCount');if(!el)return;
  count.textContent=fa(groupedInvoices(a).length)+' فاکتور';
  el.innerHTML=a.map(s=>{const p=db.products.find(p=>p.code===s.code),total=s.qty*s.price;return `<div class="item"><div class="row"><strong>${esc2(p?.name||s.code)}</strong><span class="badge">${saleTime(s)}</span></div><div class="muted">فاکتور ${esc2(invoiceKey(s))} — تعداد ${fa(s.qty)} — مبلغ ${toman(total)} — سود ${s.profitKnown?toman(s.profit):'نامعلوم'}</div></div>`}).join('')||'<div class="notice">امروز هنوز فروشی ثبت نشده است.</div>';
}
function renderTodaySalesDetail(){
  const a=salesForToday().sort((x,y)=>new Date(y.date)-new Date(x.date)),el=document.getElementById('todaySalesDetailList');if(!el)return;
  el.innerHTML=a.map(s=>{const p=db.products.find(p=>p.code===s.code),total=s.qty*s.price;return `<div class="item report-card"><div class="row"><strong>${esc2(p?.name||s.code)}</strong><span class="badge">${saleTime(s)}</span></div><div class="muted">فاکتور ${esc2(invoiceKey(s))} — تعداد ${fa(s.qty)} — مبلغ ${toman(total)} — سود ${s.profitKnown?toman(s.profit):'نامعلوم'}</div>${s.customerName||s.customerPhone?`<div class="muted">مشتری: ${esc2(s.customerName||'بدون نام')}${s.customerPhone?' — '+esc2(s.customerPhone):''}</div>`:''}</div>`}).join('')||'<div class="notice">امروز هنوز فروشی ثبت نشده است.</div>';
}
function reportToday(){reportPeriod('today','فروش امروز');renderDailyReportDetails();}
function renderDailyReportDetails(){
  const a=salesForToday().sort((x,y)=>new Date(y.date)-new Date(x.date));const box=document.getElementById('reportResult');if(!box)return;
  const grouped=groupedInvoices(a);if(!grouped.length)return;
  const detail=grouped.map(x=>{const total=x.items.reduce((n,s)=>n+s.qty*s.price,0);const lines=x.items.map(s=>{const p=db.products.find(p=>p.code===s.code);return `<div class="line"><strong>${esc2(p?.name||s.code)}</strong><div class="muted">تعداد ${fa(s.qty)} — مبلغ ${toman(s.qty*s.price)} — سود ${s.profitKnown?toman(s.profit):'نامعلوم'}</div></div>`}).join('');return `<div class="item report-card"><div class="row"><strong>فاکتور ${esc2(x.id)}</strong><span class="badge">${saleTime(x)}</span></div>${x.customerName||x.customerPhone?`<div class="muted">مشتری: ${esc2(x.customerName||'بدون نام')}${x.customerPhone?' — '+esc2(x.customerPhone):''}</div>`:''}${lines}<div class="report-meta">جمع فاکتور: ${toman(total)}</div></div>`;}).join('');
  box.insertAdjacentHTML('beforeend',`<div class="item"><strong>جزئیات فروش روزانه</strong>${detail}</div>`);
}
const _openReportPage_v21=openReportPage;
openReportPage=function(type){_openReportPage_v21(type);if(type==='sales'){const d=document.querySelector('#reportDetailBody .grid');if(d)d.classList.add('report-period-grid');}};
const _refresh_v21=refresh;
refresh=function(){_refresh_v21();renderSalesHistory();};
// Persist the bundled data on first launch so the Android WebView keeps the same initial inventory after refresh.
if(!localStorage.getItem('store_full_v2') && db.products.length){save();}


/* Product screen: always expose the bundled products through derived category cards. */
function renderProducts(){
  const q=(document.getElementById('filter')?.value||'').trim();
  const list=document.getElementById('productList');if(!list)return;
  renderCategoryManager();
  let arr=db.products.filter(p=>!q||p.name.includes(q)||p.code.includes(q));
  if(currentCategory&&!q)arr=arr.filter(p=>manualCat(p)===currentCategory);
  const cats=db.manualCategories||[];
  if(!q&&!currentCategory){
    list.innerHTML='<div class="notice">برای دیدن کالاها، دسته موردنظر را انتخاب کن یا نام/کد کالا را جستجو کن.</div>';
  }else{
    const head=currentCategory&&!q?`<div class="category-card" style="margin-bottom:10px" onclick="currentCategory=null;document.getElementById('filter').value='';renderProducts()"><div class="category-icon">↩️</div><div class="category-title">بازگشت به دسته‌ها</div><div class="category-count">${esc2(currentCategory)}</div></div>`:'';
    list.innerHTML=head+arr.map(p=>{const st=db.layers.filter(l=>l.code===p.code).reduce((a,l)=>a+l.remaining,0);return `<div class="item" onclick="selectProductFromSearch('${String(p.code).replace(/'/g,"\\'")}')"><div class="row"><strong class="product-name">${esc2(p.name)}</strong><span class="badge">${esc2(p.code)}</span></div><div class="muted stock-text">موجودی: ${fa(st)}</div><div class="product-actions" style="margin-top:9px"><div>دسته: <strong>${esc2(manualCat(p))}</strong></div><select onclick="event.stopPropagation()" onchange="changeProductCategory('${String(p.code).replace(/'/g,"\\'")}',this.value)"><option value="">بدون دسته</option>${cats.map(c=>`<option value="${c.id}" ${db.categoryOverrides[p.code]===c.id?'selected':''}>${esc2(c.name)}</option>`).join('')}</select></div></div>`}).join('')||'<div class="notice">کالایی پیدا نشد.</div>';
  }
  document.querySelectorAll('#productNames,#productNames2').forEach(dl=>dl.innerHTML=db.products.map(p=>`<option value="${esc2(p.name)}">${esc2(p.code)}</option>`).join(''));
  updateSaleCategoryOptions();
}




/* ===== FINAL CATEGORY + INVENTORY FIX - 2026-09-18 ===== */
function pashmakCategoryOf(p){
  const n=String(p?.name||'');
  if(n.includes('تروبیکا') || n.includes('گود دی')) return 'قهوه';
  const d=categoryDefs.find(x=>x[2].split('|').some(k=>n.includes(k)));
  return d?d[1]:'سایر';
}
function categoryOf(p){return pashmakCategoryOf(p);}
function pashmakCategoryIcon(name){
  const custom=(db.manualCategories||[]).find(c=>c.name===name)?.icon;
  if(custom)return custom;
  const map={
    'عسل':'🍯','رشته':'🍜','مربا':'🍓','عرقیات':'🌿','سیر':'🧄','ترشی':'🥒','زیتون':'🫒','کنسرو':'🥫','سس':'🍅','آبلیمو':'🍋','گلاب':'🌹','شیره':'🍇','ارده و حلوا':'🥣','کره بادام‌زمینی':'🥜','فرمند':'🍫','مرداس':'🍬','قهوه':'☕','سایر':'📦'
  };
  return map[name]||emojiOf(name)||'📦';
}
function ensureCoffeeMerge(){
  if(!Array.isArray(db.manualCategories))db.manualCategories=[];
  if(!db.categoryOverrides||typeof db.categoryOverrides!=='object')db.categoryOverrides={};
  let coffee=db.manualCategories.find(c=>c.name==='قهوه');
  if(!coffee){coffee={id:'CAT-COFFEE',name:'قهوه',icon:'☕'};db.manualCategories.push(coffee);}
  coffee.icon='☕';
  const oldIds=new Set(db.manualCategories.filter(c=>c.name==='گود دی'||c.name==='تروبیکا').map(c=>c.id));
  (db.products||[]).forEach(p=>{
    if(String(p.name||'').includes('گود دی')||String(p.name||'').includes('تروبیکا')) db.categoryOverrides[p.code]=coffee.id;
  });
  db.manualCategories=db.manualCategories.filter(c=>!oldIds.has(c.id));
  save();
}
function ensureAllCategoriesManaged(){
  if(!Array.isArray(db.manualCategories))db.manualCategories=[];
  if(!db.categoryOverrides||typeof db.categoryOverrides!=='object')db.categoryOverrides={};
  if(!Array.isArray(db.hiddenCategories))db.hiddenCategories=[];
  const hidden=new Set(db.hiddenCategories);
  const names=[...new Set((db.products||[]).map(p=>categoryOf(p)).filter(Boolean))];
  names.forEach(name=>{
    if(hidden.has(name))return;
    if(!db.manualCategories.some(c=>c.name===name)){
      db.manualCategories.push({id:'CAT-BASE-'+encodeURIComponent(name),name,icon:pashmakCategoryIcon(name),base:true});
    }
  });
  (db.products||[]).forEach(p=>{
    const base=categoryOf(p); if(hidden.has(base))return;
    if(!db.categoryOverrides[p.code]){
      const c=db.manualCategories.find(x=>x.name===base); if(c)db.categoryOverrides[p.code]=c.id;
    }
  });
}
function manualCat(p){
  const id=db.categoryOverrides?.[p.code];
  const c=(db.manualCategories||[]).find(x=>x.id===id);
  if(c)return c.name;
  const base=categoryOf(p); return (db.hiddenCategories||[]).includes(base)?'بدون دسته':base;
}
function categoryNames(){return [...new Set((db.manualCategories||[]).map(c=>c.name).filter(Boolean))];}
function categoryIdByName(name){return (db.manualCategories||[]).find(c=>c.name===name)?.id||null;}
function emojiOf(cat){return pashmakCategoryIcon(cat);}
function categoryVisual(name){return `<div class="category-sticker">${esc2(pashmakCategoryIcon(name))}</div>`;}
function saveCat(){save();renderProducts();updateSaleCategoryOptions();}
function createCategory(){
  const v=prompt('نام دسته جدید:');if(v===null)return;
  const n=v.trim();if(!n)return alert('نام دسته نمی‌تواند خالی باشد.');
  if(categoryNames().some(x=>x.trim().toLowerCase()===n.toLowerCase()))return alert('این دسته قبلاً وجود دارد.');
  db.manualCategories.push({id:'CAT-'+Date.now()+'-'+Math.random().toString(36).slice(2,6),name:n,icon:pashmakCategoryIcon(n)});
  const icon=prompt('استیکر/ایموجی دسته (اختیاری):',pashmakCategoryIcon(n));
  if(icon!==null){const chosenIcon=icon.trim()||pashmakCategoryIcon(n);db.manualCategories[db.manualCategories.length-1].icon=chosenIcon;}
  saveCat();
}
function renameCategory(id){
  const c=db.manualCategories.find(x=>x.id===id);if(!c)return;
  const old=c.name,v=prompt('نام جدید دسته:',old);if(v===null)return;const n=v.trim();if(!n||n===old)return;
  if(categoryNames().some(x=>x!==old&&x.trim().toLowerCase()===n.toLowerCase()))return alert('این دسته قبلاً وجود دارد.');
  c.name=n;c.icon=pashmakCategoryIcon(n);
  saveCat();
}
function changeCategoryIcon(id){
  const c=db.manualCategories.find(x=>x.id===id);if(!c)return;
  const v=prompt('استیکر/ایموجی جدید دسته:',c.icon||pashmakCategoryIcon(c.name));if(v===null)return;
  c.icon=v.trim()||pashmakCategoryIcon(c.name);saveCat();
}
function deleteCategory(id){
  const c=db.manualCategories.find(x=>x.id===id);if(!c)return;
  const count=db.products.filter(p=>manualCat(p)===c.name).length;
  if(!confirm(count?`دسته «${c.name}» با ${fa(count)} کالا حذف شود؟ کالاها به «بدون دسته» منتقل می‌شوند.`:`دسته «${c.name}» حذف شود؟`))return;
  db.products.forEach(p=>{if(db.categoryOverrides[p.code]===id)delete db.categoryOverrides[p.code];});
  db.manualCategories=db.manualCategories.filter(x=>x.id!==id);
  if(c.base){if(!db.hiddenCategories)db.hiddenCategories=[];if(!db.hiddenCategories.includes(c.name))db.hiddenCategories.push(c.name);}
  save();renderProducts();updateSaleCategoryOptions();
}
function changeProductCategory(code,id){
  if(id)db.categoryOverrides[code]=id;else delete db.categoryOverrides[code];
  save();renderProducts();
}
function currentLayerForProduct(code){
  return (db.layers||[]).filter(l=>l.code===code&&Number(l.remaining)>0).sort((a,b)=>String(a.buyDate||'').localeCompare(String(b.buyDate||'')))[0]||null;
}
function productStock(code){return (db.layers||[]).filter(l=>l.code===code).reduce((a,l)=>a+Number(l.remaining||0),0);}
function productSalePrice(code){const l=currentLayerForProduct(code);return l&&l.price!=null?Number(l.price):null;}
function productCostPrice(code){const l=currentLayerForProduct(code);return l&&l.cost!=null?Number(l.cost):null;}
function renderCategoryManager(){
  const el=document.getElementById('categoryManager');if(!el)return;
  ensureAllCategoriesManaged();ensureCoffeeMerge();
  const names=categoryNames().filter(n=>n!=='بدون دسته');
  const cards=names.map(name=>{
    const id=categoryIdByName(name),count=db.products.filter(p=>manualCat(p)===name).length;
    const safe=String(name).replace(/\\/g,'\\\\').replace(/'/g,"\\'");
    return `<div class="category-card" onclick="openCategory('${safe}')">${categoryVisual(name)}<div class="category-title">${esc2(name)}</div><div class="category-count">${fa(count)} کالا</div><div class="category-actions"><button class="btn edit-name-btn" onclick="event.stopPropagation();changeCategoryIcon('${id}')">✏️ آیکون</button><button class="btn edit-name-btn" onclick="event.stopPropagation();renameCategory('${id}')">📝 نام</button><button class="btn edit-name-btn" onclick="event.stopPropagation();deleteCategory('${id}')">🗑️ حذف</button></div></div>`;
  }).join('');
  el.innerHTML=`<div class="item"><div class="row"><strong style="font-size:17px">📂 دسته‌های کالا</strong><button class="btn" onclick="createCategory()">＋ ایجاد دسته جدید</button></div><div class="notice">روی هر دسته بزن تا کالاهای همان دسته با تعداد و قیمت نمایش داده شوند.</div><div class="category-grid" style="margin-top:10px">${cards||'<div class="notice">دسته‌ای برای نمایش وجود ندارد.</div>'}</div></div>`;
}
function openCategory(c){currentCategory=c;const f=document.getElementById('filter');if(f)f.value='';renderProducts();}
function renderProducts(){
  const q=(document.getElementById('filter')?.value||'').trim();
  const list=document.getElementById('productList');if(!list)return;
  renderCategoryManager();
  let arr=(db.products||[]).filter(p=>!q||pashmakNorm(p.name).includes(pashmakNorm(q))||pashmakNorm(p.code).includes(pashmakNorm(q)));
  if(currentCategory&&!q)arr=arr.filter(p=>manualCat(p)===currentCategory);
  if(!q&&!currentCategory){
    list.innerHTML='<div class="notice">برای دیدن کالاهای یک دسته، روی همان دسته بزن.</div>';return;
  }
  const head=currentCategory&&!q?`<div class="category-card category-back-card" onclick="currentCategory=null;renderProducts()"><div class="category-sticker">↩️</div><div class="category-title">بازگشت به دسته‌ها</div><div class="category-count">${esc2(currentCategory)}</div></div>`:'';
  list.innerHTML=head+arr.map(p=>{
    const st=productStock(p.code),sp=productSalePrice(p.code),cp=productCostPrice(p.code),cats=db.manualCategories||[];
    return `<div class="item product-detail-item"><div class="row"><strong class="product-name">${esc2(p.name)}</strong><span class="badge">${esc2(p.code)}</span></div><div class="product-price-grid"><div><span>تعداد</span><strong>${fa(st)}</strong></div><div><span>قیمت فروش</span><strong>${sp==null?'نامعلوم':toman(sp)}</strong></div><div><span>قیمت خرید</span><strong>${cp==null?'نامعلوم':toman(cp)}</strong></div></div><div class="product-actions"><div>دسته: <strong>${esc2(manualCat(p))}</strong></div><select onclick="event.stopPropagation()" onchange="changeProductCategory('${String(p.code).replace(/'/g,"\\'")}',this.value)"><option value="">بدون دسته</option>${cats.map(c=>`<option value="${c.id}" ${db.categoryOverrides[p.code]===c.id?'selected':''}>${esc2(c.name)}</option>`).join('')}</select></div></div>`;
  }).join('')||'<div class="notice">کالایی پیدا نشد.</div>';
}
function reportInventory(){
  const groups={};let buyTotal=0,saleTotal=0,buyUnknownQty=0,saleUnknownQty=0;
  (db.layers||[]).forEach(l=>{
    const qty=Number(l.remaining||0);if(qty<=0)return;
    const p=db.products.find(p=>p.code===l.code),c=manualCat(p||{name:''})||'بدون دسته';
    if(!groups[c])groups[c]={buy:0,sale:0,buyUnknown:0,saleUnknown:0,qty:0};
    groups[c].qty+=qty;
    if(l.cost!=null){const v=qty*Number(l.cost);buyTotal+=v;groups[c].buy+=v;}else{buyUnknownQty+=qty;groups[c].buyUnknown+=qty;}
    if(l.price!=null){const v=qty*Number(l.price);saleTotal+=v;groups[c].sale+=v;}else{saleUnknownQty+=qty;groups[c].saleUnknown+=qty;}
  });
  let html=`<div class="inventory-summary"><div class="inventory-total-card"><div class="label">ارزش موجودی بر اساس قیمت خرید</div><div class="inventory-big">${toman(buyTotal)}</div>${buyUnknownQty?`<div class="muted">${fa(buyUnknownQty)} واحد قیمت خرید نامعلوم دارند.</div>`:'<div class="muted">قیمت خرید همه موجودی‌های دارای موجودی مشخص است.</div>'}</div><div class="inventory-total-card"><div class="label">ارزش موجودی بر اساس قیمت فروش</div><div class="inventory-big">${toman(saleTotal)}</div>${saleUnknownQty?`<div class="muted">${fa(saleUnknownQty)} واحد قیمت فروش نامعلوم دارند.</div>`:'<div class="muted">قیمت فروش همه موجودی‌های دارای موجودی مشخص است.</div>'}</div></div>`;
  html+=Object.entries(groups).sort((a,b)=>(b[1].sale+b[1].buy)-(a[1].sale+a[1].buy)).map(([c,x])=>`<div class="item"><div class="row"><strong>${esc2(pashmakCategoryIcon(c))} ${esc2(c)}</strong><span class="badge">${fa(x.qty)} عدد</span></div><div class="inventory-row"><span>خرید: <strong>${toman(x.buy)}</strong>${x.buyUnknown?` <small>(${fa(x.buyUnknown)} نامعلوم)</small>`:''}</span><span>فروش: <strong>${toman(x.sale)}</strong>${x.saleUnknown?` <small>(${fa(x.saleUnknown)} نامعلوم)</small>`:''}</span></div></div>`).join('');
  document.getElementById('reportResult').innerHTML=html;
}
ensureCoffeeMerge();ensureAllCategoriesManaged();save();



/* ===== Pashmak Store verified fixes - 2026-09-18 ===== */
function normalizeFaText(s){return String(s||'').trim().replace(/[يى]/g,'ی').replace(/ك/g,'ک').replace(/[ۀة]/g,'ه').replace(/\u200c/g,' ').replace(/\s+/g,' ');}
/* Deleted base categories stay deleted instead of being recreated on refresh. */
function ensureHiddenCategories(){if(!Array.isArray(db.hiddenCategories))db.hiddenCategories=[];return db.hiddenCategories;}
function ensureAllCategoriesManaged(){
  if(!Array.isArray(db.manualCategories))db.manualCategories=[];
  if(!db.categoryOverrides||typeof db.categoryOverrides!=='object')db.categoryOverrides={};
  const hidden=new Set(ensureHiddenCategories());
  const names=[...new Set((db.products||[]).map(p=>categoryOf(p)).filter(Boolean))];
  names.forEach(name=>{
    if(hidden.has(name))return;
    if(!db.manualCategories.some(c=>c.name===name)){
      const id='CAT-BASE-'+encodeURIComponent(name);
      db.manualCategories.push({id,name,icon:categoryDefs.find(x=>x[1]===name)?.[0]||'📦',base:true});
    }
  });
  (db.products||[]).forEach(p=>{
    if(!db.categoryOverrides[p.code]){
      const name=categoryOf(p); if(hidden.has(name))return;
      const c=db.manualCategories.find(x=>x.name===name); if(c)db.categoryOverrides[p.code]=c.id;
    }
  });
}
function manualCat(p){
  const id=db.categoryOverrides?.[p.code];
  const c=(db.manualCategories||[]).find(x=>x.id===id);
  if(c)return c.name;
  const base=categoryOf(p); return ensureHiddenCategories().includes(base)?'بدون دسته':base;
}
function categoryNames(){return [...new Set((db.manualCategories||[]).map(c=>c.name).filter(Boolean))];}
function deleteCategory(id){
  const c=db.manualCategories.find(x=>x.id===id);if(!c)return;
  const count=db.products.filter(p=>manualCat(p)===c.name).length;
  if(!confirm(count?`دسته «${c.name}» با ${fa(count)} کالا حذف شود؟ کالاها به «بدون دسته» منتقل می‌شوند.`:`دسته «${c.name}» حذف شود؟`))return;
  db.products.forEach(p=>{if(db.categoryOverrides[p.code]===id)delete db.categoryOverrides[p.code]});
  db.manualCategories=db.manualCategories.filter(x=>x.id!==id);
  if(c.base)ensureHiddenCategories().push(c.name);
  if(db.categoryImages)delete db.categoryImages[c.name];
  save();renderProducts();updateSaleCategoryOptions();
}
function renderCategoryManager(){
  const el=document.getElementById('categoryManager');if(!el)return;
  ensureCategoryImages();ensureAllCategoriesManaged();
  const cards=categoryNames().map(name=>{
    const c=categoryIdByName(name),count=db.products.filter(p=>manualCat(p)===name).length;
    const safe=String(name).replace(/\\/g,'\\\\').replace(/'/g,"\\'");
    return `<div class="category-card" onclick="openCategory('${safe}')"><div>${categoryVisual(name)}</div><div class="category-title">${esc2(name)}</div><div class="category-count">${fa(count)} کالا</div><div class="category-actions"><button class="btn category-icon-btn" onclick="event.stopPropagation();changeCategoryImageByName('${safe}')">🖼️ عکس</button><button class="btn edit-name-btn" onclick="event.stopPropagation();renameCategory('${c}')">✏️ نام</button><button class="btn edit-name-btn" onclick="event.stopPropagation();deleteCategory('${c}')">🗑️ حذف</button></div></div>`;
  }).join('');
  el.innerHTML=`<div class="item"><div class="row"><strong style="font-size:17px">📂 مدیریت همه دسته‌ها</strong><button class="btn" onclick="createCategory()">＋ ایجاد دسته جدید</button></div><div class="notice">برای همه دسته‌ها: تغییر نام، تغییر عکس، حذف با تأیید و انتقال کالا بین دسته‌ها فعال است.</div><div class="category-grid" style="margin-top:10px">${cards||'<div class="notice">دسته‌ای برای نمایش وجود ندارد.</div>'}</div><input id="categoryImagePicker" type="file" accept="image/*" hidden onchange="handleCategoryImageUpload(event)"></div>`;
}
ensureHiddenCategories();ensureAllCategoriesManaged();



/* ===== FINAL SALES SEARCH OVERRIDE =====
   One authoritative behavior for product search:
   typed text is searched from the beginning of product name/code.
   Category is changed only when the COMPLETE category name is typed.
*/
function pashmakNorm(s){return String(s??'').trim().replace(/[يى]/g,'ی').replace(/ك/g,'ک').replace(/[ۀة]/g,'ه').replace(/\u200c/g,' ').replace(/\s+/g,' ').toLowerCase();}
function saleProductMatches(q){
  const nq=pashmakNorm(q);
  if(!nq)return [];
  return (db.products||[]).filter(p=>{
    const name=pashmakNorm(p.name), code=pashmakNorm(p.code);
    return name.startsWith(nq)||code.startsWith(nq);
  });
}
function renderSaleSearchResults(matches){
  const box=document.getElementById('saleSearchResults');
  if(!box)return;
  if(!matches.length){box.style.display='none';box.innerHTML='';return;}
  box.style.display='block';
  box.innerHTML=matches.map(p=>{
    const code=String(p.code).replace(/\\/g,'\\\\').replace(/'/g,"\\'");
    return `<button type="button" class="item" style="display:block;width:100%;text-align:right;border:0;background:transparent;cursor:pointer;margin:0;border-bottom:1px solid rgba(0,0,0,.08)" onclick="selectProductFromSearch('${code}')"><strong>${esc2(p.name)}</strong><div class="muted">${esc2(manualCat(p))} — ${esc2(p.code)}</div></button>`;
  }).join('');
}
function updateSaleProducts(){
  const cat=document.getElementById('saleCategory')?.value||'';
  const list=document.getElementById('productNames');
  if(list){
    const arr=(db.products||[]).filter(p=>!cat||manualCat(p)===cat);
    list.innerHTML=arr.map(p=>`<option value="${esc2(p.name)}">${esc2(manualCat(p))} — ${esc2(p.code)}</option>`).join('');
  }
}
function onSaleProductChange(){
  const input=document.getElementById('saleProduct'),price=document.getElementById('salePrice');
  if(!input)return;
  const q=input.value||'';
  if(!pashmakNorm(q)){
    if(price)price.value='';
    renderSaleSearchResults([]);
    updateSaleProducts();
    return;
  }
  const nq=pashmakNorm(q);
  const exactCat=(categoryNames()||[]).find(c=>pashmakNorm(c)===nq);
  if(exactCat && nq.length>1){
    const sel=document.getElementById('saleCategory');
    if(sel){sel.value=exactCat;updateSaleProducts();}
    if(price)price.value='';
    renderSaleSearchResults(saleProductMatches(q));
    return;
  }
  /* IMPORTANT: partial typing NEVER changes category. */
  const matches=saleProductMatches(q);
  renderSaleSearchResults(matches);
  const list=document.getElementById('productNames');
  if(list)list.innerHTML=matches.map(x=>`<option value="${esc2(x.name)}">${esc2(manualCat(x))} — ${esc2(x.code)}</option>`).join('');
  const p=(db.products||[]).find(x=>pashmakNorm(x.name)===nq||pashmakNorm(x.code)===nq);
  if(!p){if(price)price.value='';return;}
  const l=(db.layers||[]).find(x=>x.code===p.code&&x.remaining>0&&x.price!=null);
  if(price)price.value=l?l.price:'';
}
function selectProductFromSearch(code){
  const p=(db.products||[]).find(x=>x.code===code);if(!p)return;
  const input=document.getElementById('saleProduct');
  if(input)input.value=p.name;
  const cat=document.getElementById('saleCategory');
  if(cat){cat.value=manualCat(p);updateSaleProducts();}
  renderSaleSearchResults([]);
  onSaleProductChange();
}



/* ===== PASHMAK FINAL SEARCH/CATEGORY UX FIX - 2026-09-18 ===== */
(function(){
  function norm(s){return pashmakNorm(s||'');}
  const searchCache=new Map();
  function productSearchMatches(q){
    const nq=norm(q); if(!nq)return [];
    if(searchCache.has(nq))return searchCache.get(nq);
    const out=(db.products||[]).filter(p=>norm(p.name).startsWith(nq)||norm(p.code).startsWith(nq));
    searchCache.set(nq,out); return out;
  }
  function syncProductCategoryOverrides(){
    ensureCoffeeMerge(); ensureAllCategoriesManaged();
    (db.products||[]).forEach(p=>{
      const name=categoryOf(p), c=(db.manualCategories||[]).find(x=>x.name===name);
      if(c && !((db.hiddenCategories||[]).includes(name))) db.categoryOverrides[p.code]=c.id;
    });
  }
  function productCard(p,cats){
    const st=productStock(p.code),sp=productSalePrice(p.code),cp=productCostPrice(p.code),cat=manualCat(p);
    const safe=String(p.code).replace(/\\/g,'\\\\').replace(/'/g,"\\'");
    return `<div class="item product-detail-item"><div class="row"><strong class="product-name">${esc2(p.name)}</strong><span class="badge">${esc2(p.code)}</span></div><div class="product-price-grid"><div><span>تعداد</span><strong>${fa(st)}</strong></div><div><span>قیمت فروش</span><strong>${sp==null?'نامعلوم':toman(sp)}</strong></div><div><span>قیمت خرید</span><strong>${cp==null?'نامعلوم':toman(cp)}</strong></div></div><div class="product-actions"><div>دسته: <strong>${esc2(cat)}</strong></div><select onclick="event.stopPropagation()" onchange="changeProductCategory('${safe}',this.value)"><option value="">بدون دسته</option>${cats.map(c=>`<option value="${c.id}" ${c.name===cat?'selected':''}>${esc2(c.name)}</option>`).join('')}</select></div></div>`;
  }
  window.openCategory=function(name){syncProductCategoryOverrides();currentCategory=name;const f=document.getElementById('filter');if(f)f.value='';renderProducts();};
  window.renderProducts=function(){
    syncProductCategoryOverrides();
    const f=document.getElementById('filter'),q=(f?.value||'').trim(),list=document.getElementById('productList');if(!list)return;
    renderCategoryManager();
    const cats=db.manualCategories||[];
    let arr;
    if(q){
      /* Product search is global and matches only from the beginning of name/code. */
      arr=productSearchMatches(q);
    }else if(currentCategory){
      arr=(db.products||[]).filter(p=>manualCat(p)===currentCategory);
    }else{
      list.innerHTML='<div class="notice">برای دیدن کالاهای یک دسته، روی همان دسته بزن؛ یا نام/کد کالا را جستجو کن.</div>';
      return;
    }
    const head=currentCategory&&!q?`<div class="category-card category-back-card" onclick="currentCategory=null;renderProducts()"><div class="category-sticker">↩️</div><div class="category-title">بازگشت به دسته‌ها</div><div class="category-count">${esc2(currentCategory)}</div></div>`:'';
    list.innerHTML=head+(arr||[]).map(p=>productCard(p,cats)).join('')||'<div class="notice">کالایی با این عبارت پیدا نشد.</div>';
  };
  window.onSaleProductChange=function(){
    const input=document.getElementById('saleProduct');if(!input)return;
    const q=input.value||'',box=document.getElementById('saleSearchResults'),price=document.getElementById('salePrice');
    if(!norm(q)){if(price)price.value='';renderSaleSearchResults([]);updateSaleProducts();return;}
    /* Never switch category while the user is typing. Search is global. */
    const matches=productSearchMatches(q);
    renderSaleSearchResults(matches);
    const exact=(db.products||[]).find(p=>norm(p.name)===norm(q)||norm(p.code)===norm(q));
    if(exact){
      const l=(db.layers||[]).find(x=>x.code===exact.code&&Number(x.remaining)>0&&x.price!=null);
      if(price)price.value=l?l.price:'';
    }else if(price)price.value='';
  };
  window.renderSaleSearchResults=function(matches){
    const box=document.getElementById('saleSearchResults');if(!box)return;
    if(!matches.length){box.style.display='none';box.innerHTML='';return;}
    box.style.display='block';
    box.innerHTML=matches.map(p=>{const code=String(p.code).replace(/\\/g,'\\\\').replace(/'/g,"\\'");return `<button type="button" class="sale-search-item" onclick="selectProductFromSearch('${code}')"><strong>${esc2(p.name)}</strong><span>${esc2(manualCat(p))} — ${esc2(p.code)}</span></button>`;}).join('');
  };
  window.selectProductFromSearch=function(code){
    const p=(db.products||[]).find(x=>x.code===code);if(!p)return;
    const input=document.getElementById('saleProduct');if(input)input.value=p.name;
    const cat=document.getElementById('saleCategory');if(cat){cat.value='';}
    renderSaleSearchResults([]);onSaleProductChange();
  };
  window.updateSaleProducts=function(){
    const cat=document.getElementById('saleCategory')?.value||'',list=document.getElementById('productNames');if(!list)return;
    const arr=(db.products||[]).filter(p=>!cat||manualCat(p)===cat);
    list.innerHTML=arr.map(p=>`<option value="${esc2(p.name)}">${esc2(manualCat(p))} — ${esc2(p.code)}</option>`).join('');
  };
  /* Avoid rebuilding the whole sales form/datalist on every keystroke. */
  let saleFrame=0;
  const saleInput=document.getElementById('saleProduct');
  if(saleInput){
    saleInput.removeAttribute('oninput');
    saleInput.addEventListener('input',function(){cancelAnimationFrame(saleFrame);saleFrame=requestAnimationFrame(()=>window.onSaleProductChange());});
  }
})();



/* ===== FINAL AUTHORITATIVE CATEGORY/SEARCH FIX - 2026-09-19 ===== */
(function(){
  let coffeeMergeDone=false;
  /* Do not overwrite a user's manual category assignment on every render. */
  window.syncProductCategoryOverrides=function(){
    if(!coffeeMergeDone && typeof ensureCoffeeMerge==='function'){ ensureCoffeeMerge(); coffeeMergeDone=true; }
    if(!Array.isArray(db.manualCategories)) db.manualCategories=[];
    if(!db.categoryOverrides || typeof db.categoryOverrides!=='object') db.categoryOverrides={};
    if(!Array.isArray(db.hiddenCategories)) db.hiddenCategories=[];
    const hidden=new Set(db.hiddenCategories);
    (db.products||[]).forEach(function(p){
      if(db.categoryOverrides[p.code]) return;
      const name=categoryOf(p);
      if(hidden.has(name)) return;
      const c=db.manualCategories.find(x=>x.name===name);
      if(c) db.categoryOverrides[p.code]=c.id;
    });
  };

  window.productSearchMatches=function(q){
    const nq=pashmakNorm(q||'');
    if(!nq) return [];
    return (db.products||[]).filter(function(p){
      return pashmakNorm(p.name).startsWith(nq) || pashmakNorm(p.code).startsWith(nq);
    });
  };

  window.renderProducts=function(){
    syncProductCategoryOverrides();
    const f=document.getElementById('filter'), q=(f?.value||'').trim(), list=document.getElementById('productList');
    if(!list) return;
    renderCategoryManager();
    const cats=db.manualCategories||[];
    let arr;
    if(q) arr=productSearchMatches(q);
    else if(currentCategory) arr=(db.products||[]).filter(p=>manualCat(p)===currentCategory);
    else { list.innerHTML='<div class="notice">برای دیدن کالاهای یک دسته، روی همان دسته بزن؛ یا نام/کد کالا را جستجو کن.</div>'; return; }
    const head=currentCategory&&!q?`<div class="category-card category-back-card" onclick="currentCategory=null;renderProducts()"><div class="category-sticker">↩️</div><div class="category-title">بازگشت به دسته‌ها</div><div class="category-count">${esc2(currentCategory)}</div></div>`:'';
    list.innerHTML=head+(arr||[]).map(function(p){
      const st=productStock(p.code),sp=productSalePrice(p.code),cp=productCostPrice(p.code),cat=manualCat(p),safe=String(p.code).replace(/\\/g,'\\\\').replace(/'/g,"\\'");
      return `<div class="item product-detail-item"><div class="row"><strong class="product-name">${esc2(p.name)}</strong><span class="badge">${esc2(p.code)}</span></div><div class="product-price-grid"><div><span>تعداد</span><strong>${fa(st)}</strong></div><div><span>قیمت فروش</span><strong>${sp==null?'نامعلوم':toman(sp)}</strong></div><div><span>قیمت خرید</span><strong>${cp==null?'نامعلوم':toman(cp)}</strong></div></div><div class="product-actions"><div>دسته: <strong>${esc2(cat)}</strong></div><select onclick="event.stopPropagation()" onchange="changeProductCategory('${safe}',this.value)"><option value="">بدون دسته</option>${cats.map(c=>`<option value="${c.id}" ${c.name===cat?'selected':''}>${esc2(c.name)}</option>`).join('')}</select></div></div>`;
    }).join('')||'<div class="notice">کالایی با این عبارت پیدا نشد.</div>';
  };

  window.openCategory=function(name){
    syncProductCategoryOverrides();
    currentCategory=name;
    const f=document.getElementById('filter'); if(f) f.value='';
    renderProducts();
  };

  window.onSaleProductChange=function(){
    const input=document.getElementById('saleProduct'), price=document.getElementById('salePrice');
    if(!input) return;
    const q=input.value||'';
    if(!pashmakNorm(q)){ if(price)price.value=''; renderSaleSearchResults([]); return; }
    const matches=productSearchMatches(q);
    renderSaleSearchResults(matches);
    const exact=(db.products||[]).find(p=>pashmakNorm(p.name)===pashmakNorm(q)||pashmakNorm(p.code)===pashmakNorm(q));
    if(exact){
      const l=(db.layers||[]).find(x=>x.code===exact.code&&Number(x.remaining)>0&&x.price!=null);
      if(price) price.value=l?l.price:'';
    } else if(price) price.value='';
  };

  window.renderSaleSearchResults=function(matches){
    const box=document.getElementById('saleSearchResults'); if(!box)return;
    if(!matches.length){box.style.display='none';box.innerHTML='';return;}
    box.style.display='block';
    box.innerHTML=matches.map(function(p){
      const code=String(p.code).replace(/\\/g,'\\\\').replace(/'/g,"\\'");
      return `<button type="button" class="sale-search-item" onclick="selectProductFromSearch('${code}')"><strong>${esc2(p.name)}</strong><span>${esc2(manualCat(p))} — ${esc2(p.code)}</span></button>`;
    }).join('');
  };

  window.selectProductFromSearch=function(code){
    const p=(db.products||[]).find(x=>x.code===code); if(!p)return;
    const input=document.getElementById('saleProduct'); if(input)input.value=p.name;
    const cat=document.getElementById('saleCategory'); if(cat)cat.value='';
    renderSaleSearchResults([]); onSaleProductChange();
  };

  /* One-time migration: merge Good Day and Tropica into coffee without later undoing manual category changes. */
  if(typeof ensureCoffeeMerge==='function'){ ensureCoffeeMerge(); coffeeMergeDone=true; }
  syncProductCategoryOverrides();
  if(typeof save==='function') save();
})();



/* ===== FINAL DETAIL NAVIGATION FIX - 2026-09-19 ===== */
(function(){
  function enc(v){return encodeURIComponent(String(v));}
  function dec(v){try{return decodeURIComponent(v)}catch(e){return String(v||'')}}
  const weekDays=['یکشنبه','دوشنبه','سه‌شنبه','چهارشنبه','پنجشنبه','جمعه','شنبه'];
  function dayLabelFromDate(date){
    const d=new Date(date);
    const j=saleDateParts({date:date});
    return weekDays[d.getDay()]+' '+fa(String(j.jy).padStart(4,'0')+'/'+String(j.jm).padStart(2,'0')+'/'+String(j.jd).padStart(2,'0'));
  }
  function invoicesForDay(dayKey){
    return groupedInvoices(activeSales().filter(s=>saleDateKey(s)===dayKey));
  }

  window.renderSalesHistory=function(){
    const el=document.getElementById('salesHistoryList'); if(!el)return;
    const inv=groupedInvoices(activeSales());
    if(!inv.length){el.innerHTML='<div class="notice">هنوز هیچ فاکتور فروشی ثبت نشده است.</div>';return;}
    const days={};
    inv.forEach(x=>{const k=saleDateKey(x);if(!days[k])days[k]={date:x.date,count:0};days[k].count++;});
    el.innerHTML=Object.entries(days).map(function([k,x]){
      const total=invoicesForDay(k).reduce((a,inv)=>a+inv.items.reduce((s,it)=>s+it.qty*it.price,0),0);
      return `<div class="item clickable history-day-card" onclick="showSalesHistoryDay('${enc(k)}')"><div class="row"><strong class="history-day-title">${dayLabelFromDate(x.date)}</strong><span class="badge">${fa(x.count)} فاکتور</span></div><div class="muted">جمع فروش روز: <strong>${toman(total)}</strong></div><div class="history-open-hint">برای دیدن فاکتورهای این روز لمس کنید ›</div></div>`;
    }).join('');
  };

  window.showSalesHistoryDay=function(encodedDay){
    const key=dec(encodedDay), list=document.getElementById('salesHistoryList'); if(!list)return;
    const inv=invoicesForDay(key);
    if(!inv.length){renderSalesHistory();return;}
    const title=dayLabelFromDate(inv[0].date);
    list.innerHTML=`<button class="back history-back-btn" type="button" onclick="renderSalesHistory()">‹ بازگشت به روزها</button><h3 class="history-section-title">${title}</h3>`+
      inv.map(function(x){
        const total=x.items.reduce((a,s)=>a+s.qty*s.price,0);
        const customer=(x.customerName||x.customerPhone)?`<div class="muted">مشتری: ${esc2(x.customerName||'بدون نام')}${x.customerPhone?' — '+esc2(x.customerPhone):''}</div>`:'';
        return `<div class="item clickable invoice-card" onclick="showSalesHistoryInvoice('${enc(x.id)}')"><div class="row"><strong>فاکتور ${esc2(x.id)}</strong><span class="badge">${saleTime(x)}</span></div>${customer}<div class="muted">${fa(x.items.length)} قلم — جمع ${toman(total)}</div><div class="history-open-hint">برای دیدن اقلام و جزئیات فاکتور لمس کنید ›</div></div>`;
      }).join('');
  };

  window.showSalesHistoryInvoice=function(encodedId){
    const id=dec(encodedId), x=groupedInvoices(activeSales()).find(v=>String(v.id)===String(id)), list=document.getElementById('salesHistoryList'); if(!list||!x)return;
    const total=x.items.reduce((a,s)=>a+s.qty*s.price,0);
    const profitKnown=x.items.every(s=>s.profitKnown!==false);
    const profit=x.items.reduce((a,s)=>a+(s.profitKnown===false?0:(s.profit||0)),0);
    const customer=(x.customerName||x.customerPhone)?`<div class="item"><strong>مشتری</strong><div class="muted">${esc2(x.customerName||'بدون نام')}${x.customerPhone?' — '+esc2(x.customerPhone):''}</div></div>`:'';
    list.innerHTML=`<button class="back history-back-btn" type="button" onclick="showSalesHistoryDay('${enc(saleDateKey(x))}')">‹ بازگشت به فاکتورهای روز</button><h3 class="history-section-title">جزئیات فاکتور</h3><div class="item invoice-summary"><div class="row"><strong>فاکتور ${esc2(x.id)}</strong><span class="badge">${saleTime(x)}</span></div><div class="muted">${dayLabelFromDate(x.date)}</div></div>${customer}<div class="item"><strong class="detail-heading">اقلام فروخته‌شده</strong>${x.items.map(function(s){const p=db.products.find(p=>p.code===s.code);return `<div class="line invoice-line"><div class="row"><strong>${esc2(p?.name||s.code)}</strong><span>${fa(s.qty)} عدد</span></div><div class="muted">قیمت واحد: ${toman(s.price)} — مبلغ: ${toman(s.qty*s.price)}</div><div class="muted">سود: ${s.profitKnown?toman(s.profit):'نامعلوم'}</div></div>`}).join('')}</div><div class="item invoice-total"><div>جمع فاکتور: <strong>${toman(total)}</strong></div><div>سود: <strong>${profitKnown?toman(profit):'نامعلوم'}</strong></div></div>`;
  };

  /* Product/category page: touching a category opens ONLY that category.
     The old large "بازگشت به دسته‌ها" card is replaced by a real back button. */
  window.renderProducts=function(){
    syncProductCategoryOverrides();
    const f=document.getElementById('filter'),q=(f?.value||'').trim(),list=document.getElementById('productList');
    if(!list)return;
    const cats=db.manualCategories||[];
    if(!q && !currentCategory){
      renderCategoryManager();
      list.innerHTML='<div class="notice">برای دیدن کالاهای یک دسته، روی همان دسته بزن؛ یا نام/کد کالا را جستجو کن.</div>';
      return;
    }
    const arr=q?productSearchMatches(q):(db.products||[]).filter(p=>manualCat(p)===currentCategory);
    let head='';
    if(currentCategory&&!q){
      const safe=String(currentCategory).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;');
      head=`<button class="back category-real-back" type="button" onclick="currentCategory=null;renderProducts()">‹ بازگشت به دسته‌ها</button><div class="current-category-title"><span class="category-sticker">${esc2(pashmakCategoryIcon(currentCategory))}</span><strong>${safe}</strong><span class="badge">${fa(arr.length)} کالا</span></div>`;
    }
    if(q && currentCategory){
      head=`<button class="back category-real-back" type="button" onclick="currentCategory=null;document.getElementById('filter').value='';renderProducts()">‹ بازگشت به دسته‌ها</button>`;
    }
    list.innerHTML=head+(arr||[]).map(function(p){
      const st=productStock(p.code),sp=productSalePrice(p.code),cp=productCostPrice(p.code),cat=manualCat(p),safe=String(p.code).replace(/\\/g,'\\\\').replace(/'/g,"\\'");
      return `<div class="item product-detail-item"><div class="row"><strong class="product-name">${esc2(p.name)}</strong><span class="badge">${esc2(p.code)}</span></div><div class="product-price-grid"><div><span>تعداد</span><strong>${fa(st)}</strong></div><div><span>قیمت فروش</span><strong>${sp==null?'نامعلوم':toman(sp)}</strong></div><div><span>قیمت خرید</span><strong>${cp==null?'نامعلوم':toman(cp)}</strong></div></div><div class="product-actions"><div>دسته: <strong>${esc2(cat)}</strong></div><select onclick="event.stopPropagation()" onchange="changeProductCategory('${safe}',this.value)"><option value="">بدون دسته</option>${cats.map(c=>`<option value="${c.id}" ${c.name===cat?'selected':''}>${esc2(c.name)}</option>`).join('')}</select></div></div>`;
    }).join('')||'<div class="notice">کالایی با این عبارت پیدا نشد.</div>';
  };

  /* Inventory report: category totals remain on the first screen; each category opens
     a second screen with product-level purchase/sale values. */
  function inventoryGroups(){
    const groups={}; let buyTotal=0,saleTotal=0,buyUnknownQty=0,saleUnknownQty=0;
    (db.layers||[]).forEach(function(l){
      const qty=Number(l.remaining||0); if(qty<=0)return;
      const p=db.products.find(p=>p.code===l.code), c=manualCat(p||{name:''})||'بدون دسته';
      if(!groups[c])groups[c]={buy:0,sale:0,buyUnknown:0,saleUnknown:0,qty:0};
      groups[c].qty+=qty;
      if(l.cost!=null){const v=qty*Number(l.cost);buyTotal+=v;groups[c].buy+=v;}else{buyUnknownQty+=qty;groups[c].buyUnknown+=qty;}
      if(l.price!=null){const v=qty*Number(l.price);saleTotal+=v;groups[c].sale+=v;}else{saleUnknownQty+=qty;groups[c].saleUnknown+=qty;}
    });
    return {groups,buyTotal,saleTotal,buyUnknownQty,saleUnknownQty};
  }
  function inventoryProductsForCategory(cat){
    const out={};
    (db.layers||[]).forEach(function(l){
      const qty=Number(l.remaining||0);if(qty<=0)return;
      const p=db.products.find(p=>p.code===l.code);if(!p||manualCat(p)!==cat)return;
      if(!out[p.code])out[p.code]={name:p.name,qty:0,buy:0,sale:0,buyUnknown:0,saleUnknown:0};
      const x=out[p.code];x.qty+=qty;
      if(l.cost!=null)x.buy+=qty*Number(l.cost);else x.buyUnknown+=qty;
      if(l.price!=null)x.sale+=qty*Number(l.price);else x.saleUnknown+=qty;
    });
    return Object.values(out).sort((a,b)=>a.name.localeCompare(b.name,'fa'));
  }
  window.reportInventory=function(){
    const data=inventoryGroups();
    let html=`<div class="inventory-summary"><div class="inventory-total-card"><div class="label">ارزش موجودی بر اساس قیمت خرید</div><div class="inventory-big">${toman(data.buyTotal)}</div>${data.buyUnknownQty?`<div class="muted">${fa(data.buyUnknownQty)} واحد قیمت خرید نامعلوم دارند.</div>`:'<div class="muted">قیمت خرید همه موجودی‌های دارای موجودی مشخص است.</div>'}</div><div class="inventory-total-card"><div class="label">ارزش موجودی بر اساس قیمت فروش</div><div class="inventory-big">${toman(data.saleTotal)}</div>${data.saleUnknownQty?`<div class="muted">${fa(data.saleUnknownQty)} واحد قیمت فروش نامعلوم دارند.</div>`:'<div class="muted">قیمت فروش همه موجودی‌های دارای موجودی مشخص است.</div>'}</div></div>`;
    html+=Object.entries(data.groups).sort((a,b)=>(b[1].sale+b[1].buy)-(a[1].sale+a[1].buy)).map(function([c,x]){
      return `<div class="item inventory-category-card clickable" onclick="showInventoryCategory('${enc(c)}')"><div class="row"><strong>${esc2(pashmakCategoryIcon(c))} ${esc2(c)}</strong><span class="badge">${fa(x.qty)} عدد</span></div><div class="inventory-row"><span>خرید: <strong>${toman(x.buy)}</strong>${x.buyUnknown?` <small>(${fa(x.buyUnknown)} نامعلوم)</small>`:''}</span><span>فروش: <strong>${toman(x.sale)}</strong>${x.saleUnknown?` <small>(${fa(x.saleUnknown)} نامعلوم)</small>`:''}</span></div><div class="history-open-hint">برای دیدن ارزش هر کالا در این دسته لمس کنید ›</div></div>`;
    }).join('');
    document.getElementById('reportResult').innerHTML=html;
  };
  window.showInventoryCategory=function(encodedCat){
    const cat=dec(encodedCat), list=document.getElementById('reportResult');if(!list)return;
    const items=inventoryProductsForCategory(cat);
    const totals=items.reduce((a,x)=>({qty:a.qty+x.qty,buy:a.buy+x.buy,sale:a.sale+x.sale,buyUnknown:a.buyUnknown+x.buyUnknown,saleUnknown:a.saleUnknown+x.saleUnknown}),{qty:0,buy:0,sale:0,buyUnknown:0,saleUnknown:0});
    list.innerHTML=`<button class="back history-back-btn" type="button" onclick="reportInventory()">‹ بازگشت به دسته‌ها</button><h3 class="history-section-title">${esc2(pashmakCategoryIcon(cat))} ارزش موجودی ${esc2(cat)}</h3><div class="inventory-detail-summary"><div>تعداد کل: <strong>${fa(totals.qty)}</strong></div><div>خرید کل: <strong>${toman(totals.buy)}</strong>${totals.buyUnknown?` <small>(${fa(totals.buyUnknown)} نامعلوم)</small>`:''}</div><div>فروش کل: <strong>${toman(totals.sale)}</strong>${totals.saleUnknown?` <small>(${fa(totals.saleUnknown)} نامعلوم)</small>`:''}</div></div>`+
      (items.length?items.map(function(x){return `<div class="item inventory-product-detail"><div class="row"><strong>${esc2(x.name)}</strong><span class="badge">${fa(x.qty)} عدد</span></div><div class="inventory-row"><span>ارزش خرید: <strong>${toman(x.buy)}</strong>${x.buyUnknown?` <small>(${fa(x.buyUnknown)} نامعلوم)</small>`:''}</span><span>ارزش فروش: <strong>${toman(x.sale)}</strong>${x.saleUnknown?` <small>(${fa(x.saleUnknown)} نامعلوم)</small>`:''}</span></div></div>`}).join(''):'<div class="notice">موجودی فعالی در این دسته وجود ندارد.</div>');
  };
})();
